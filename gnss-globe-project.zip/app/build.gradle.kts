plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Builds from the main branch install as "GNSS Globe"; any other branch (e.g. dev) installs
// as a separate "GNSS Globe Dev" app so both can live side by side on the tablet.
val branch = System.getenv("GITHUB_REF_NAME") ?: "main"
val repo = System.getenv("GITHUB_REPOSITORY") ?: "moonpatel23/gnss-globe"
val isMain = branch == "main"

android {
    namespace = "com.moon.gnssglobe"
    compileSdk = 35

    defaultConfig {
        applicationId = if (isMain) "com.moon.gnssglobe" else "com.moon.gnssglobe.dev"
        minSdk = 26
        targetSdk = 35
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "1.0." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0") + (if (isMain) "" else "-$branch")
        resValue("string", "app_name", if (isMain) "GNSS Globe" else "GNSS Globe Dev")
        resValue("color", "icon_bg", if (isMain) "#0B1630" else "#4A1450")
        // Satellite catalog the app refreshes from this repo/branch whenever it is online.
        buildConfigField("String", "CATALOG_URL", "\"https://raw.githubusercontent.com/$repo/$branch/satdb.json\"")
        buildConfigField("String", "CHANNEL", "\"$branch\"")
    }

    buildFeatures { buildConfig = true }

    // Fixed signing key so each new build installs over the previous one.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.webkit:webkit:1.12.1")
}
