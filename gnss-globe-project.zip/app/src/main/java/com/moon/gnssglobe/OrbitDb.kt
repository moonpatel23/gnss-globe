package com.moon.gnssglobe

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * On-tablet orbit database (SQLite). Holds only data that is still valid; every row carries its own
 * expiry time and [purge] deletes expired rows. No history is kept: one row per satellite and kind.
 *
 *   eph  broadcast ephemeris (GPS, QZSS, Galileo)      expires toe + 4 h
 *   alm  broadcast almanac (GPS)                        expires toa + 14 days
 *   gp   CelesTrak SGP4 elements (all constellations)   expires epoch + 14 days
 *   meta key/value (last download time and result)
 */
class OrbitDb(context: Context) : SQLiteOpenHelper(context, "orbits.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE eph (sys INTEGER, svid INTEGER, iod INTEGER, toe REAL, expires INTEGER, json TEXT, PRIMARY KEY (sys, svid))")
        db.execSQL("CREATE TABLE alm (sys INTEGER, svid INTEGER, toa REAL, expires INTEGER, json TEXT, PRIMARY KEY (sys, svid))")
        db.execSQL("CREATE TABLE gp (norad INTEGER PRIMARY KEY, name TEXT, sys INTEGER, line1 TEXT, line2 TEXT, epoch INTEGER, expires INTEGER)")
        db.execSQL("CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        for (t in listOf("eph", "alm", "gp", "meta")) db.execSQL("DROP TABLE IF EXISTS $t")
        onCreate(db)
    }

    /** Stores an ephemeris unless the stored one for that satellite is newer. Returns true if stored. */
    fun putEph(e: KeplerEph): Boolean {
        if (e.expiresMs() < System.currentTimeMillis()) return false
        val db = writableDatabase
        db.rawQuery("SELECT toe, iod FROM eph WHERE sys = ? AND svid = ?", arrayOf("${e.sys}", "${e.svid}")).use { c ->
            if (c.moveToFirst() && (c.getDouble(0) > e.toeAbs || (c.getDouble(0) == e.toeAbs && c.getInt(1) == e.iod))) return false
        }
        db.insertWithOnConflict("eph", null, ContentValues().apply {
            put("sys", e.sys); put("svid", e.svid); put("iod", e.iod); put("toe", e.toeAbs)
            put("expires", e.expiresMs()); put("json", OrbitJson.eph(e).toString())
        }, SQLiteDatabase.CONFLICT_REPLACE)
        return true
    }

    fun putAlm(a: KeplerAlm): Boolean {
        if (a.expiresMs() < System.currentTimeMillis()) return false
        val db = writableDatabase
        db.rawQuery("SELECT toa FROM alm WHERE sys = ? AND svid = ?", arrayOf("${a.sys}", "${a.svid}")).use { c ->
            if (c.moveToFirst() && c.getDouble(0) >= a.toaAbs) return false
        }
        db.insertWithOnConflict("alm", null, ContentValues().apply {
            put("sys", a.sys); put("svid", a.svid); put("toa", a.toaAbs)
            put("expires", a.expiresMs()); put("json", OrbitJson.alm(a).toString())
        }, SQLiteDatabase.CONFLICT_REPLACE)
        return true
    }

    /** Replaces the whole GP table with a fresh download (one transaction). */
    fun replaceGp(list: List<GpRecord>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("gp", null, null)
            for (g in list) db.insertWithOnConflict("gp", null, ContentValues().apply {
                put("norad", g.norad); put("name", g.name); put("sys", g.sys)
                put("line1", g.line1); put("line2", g.line2); put("epoch", g.epochMs); put("expires", g.expiresMs())
            }, SQLiteDatabase.CONFLICT_REPLACE)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /** Deletes every expired row. Returns how many were removed. */
    fun purge(nowMs: Long = System.currentTimeMillis()): Int {
        val db = writableDatabase
        val args = arrayOf("$nowMs")
        return db.delete("eph", "expires < ?", args) + db.delete("alm", "expires < ?", args) +
            db.delete("gp", "expires < ?", args)
    }

    fun clearAll() {
        val db = writableDatabase
        for (t in listOf("eph", "alm", "gp", "meta")) db.delete(t, null, null)
    }

    private fun jsonColumn(table: String): JSONArray {
        val out = JSONArray()
        readableDatabase.rawQuery("SELECT json FROM $table", null).use { c ->
            while (c.moveToNext()) try { out.put(JSONObject(c.getString(0))) } catch (e: Exception) { }
        }
        return out
    }

    fun ephJson() = jsonColumn("eph")
    fun almJson() = jsonColumn("alm")

    fun gpJson(): JSONArray {
        val out = JSONArray()
        readableDatabase.rawQuery("SELECT norad, name, sys, line1, line2, epoch FROM gp", null).use { c ->
            while (c.moveToNext()) out.put(JSONObject()
                .put("norad", c.getInt(0)).put("name", c.getString(1)).put("sys", c.getInt(2))
                .put("l1", c.getString(3)).put("l2", c.getString(4)).put("epoch", c.getLong(5)))
        }
        return out
    }

    fun count(table: String): Int =
        readableDatabase.rawQuery("SELECT COUNT(*) FROM $table", null).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }

    fun meta(key: String): String? =
        readableDatabase.rawQuery("SELECT value FROM meta WHERE key = ?", arrayOf(key)).use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }

    fun setMeta(key: String, value: String) {
        writableDatabase.insertWithOnConflict("meta", null,
            ContentValues().apply { put("key", key); put("value", value) }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    companion object {
        /** Downloads CelesTrak GNSS elements; falls back to the per-constellation groups. */
        fun downloadGp(): List<GpRecord> {
            val primary = try { GpElements.parse(httpGet(GpElements.URL_GNSS)) } catch (e: Exception) { emptyList() }
            if (primary.size >= 40) return primary
            val merged = LinkedHashMap<Int, GpRecord>()
            primary.forEach { merged[it.norad] = it }
            var lastError: Exception? = null
            for (u in GpElements.URL_GROUPS) {
                try { GpElements.parse(httpGet(u)).forEach { merged[it.norad] = it } } catch (e: Exception) { lastError = e }
            }
            if (merged.isEmpty() && lastError != null) throw lastError
            return merged.values.toList()
        }

        private fun httpGet(url: String): String {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15_000; c.readTimeout = 20_000
            c.setRequestProperty("User-Agent", "GNSS-Globe-Android (personal)")
            try {
                if (c.responseCode != 200) throw IllegalStateException("HTTP ${c.responseCode}")
                return c.inputStream.bufferedReader().use { it.readText() }
            } finally { c.disconnect() }
        }
    }
}

/** JSON shapes sent to the page. Times are absolute GPS seconds; angles radians. */
object OrbitJson {
    fun eph(e: KeplerEph): JSONObject = JSONObject()
        .put("sys", e.sys).put("svid", e.svid).put("iod", e.iod).put("toe", e.toeAbs)
        .put("sqrtA", e.sqrtA).put("e", e.e).put("i0", e.i0).put("Omega0", e.omega0)
        .put("omega", e.omega).put("M0", e.m0).put("dn", e.deltaN)
        .put("OmegaDot", e.omegaDot).put("IDOT", e.idot)
        .put("Cuc", e.cuc).put("Cus", e.cus).put("Crc", e.crc).put("Crs", e.crs)
        .put("Cic", e.cic).put("Cis", e.cis)
        .put("clock", e.hasClock).put("toc", e.tocAbs).put("af0", e.af0).put("af1", e.af1).put("af2", e.af2)
        .put("health", e.health).put("ura", e.ura).put("week", e.week)
        .put("rx", e.receivedMs).put("exp", e.expiresMs())

    fun alm(a: KeplerAlm): JSONObject = JSONObject()
        .put("sys", a.sys).put("svid", a.svid).put("toa", a.toaAbs)
        .put("sqrtA", a.sqrtA).put("e", a.e).put("i", a.i).put("Omega0", a.omega0)
        .put("OmegaDot", a.omegaDot).put("omega", a.omega).put("M0", a.m0)
        .put("af0", a.af0).put("af1", a.af1).put("health", a.health)
        .put("rx", a.receivedMs).put("exp", a.expiresMs())
}
