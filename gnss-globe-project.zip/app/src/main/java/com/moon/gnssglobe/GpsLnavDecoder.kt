package com.moon.gnssglobe

import org.json.JSONObject

/**
 * Decodes GPS L1 C/A LNAV subframes 2 and 3 (the broadcast ephemeris) from the raw
 * navigation messages Android delivers via GnssNavigationMessage, per IS-GPS-200.
 *
 * Android packs each 30-bit word into the low 30 bits of 4 bytes, MSB first, 10 words
 * per subframe (40 bytes). Some chips deliver the bits as transmitted (D1-D24 inverted
 * when the previous word's D30 is 1), others deliver them already de-inverted, so both
 * are tried and the subframe is only accepted if every word passes the parity check.
 */
class GpsLnavDecoder {

    data class Ephemeris(
        val svid: Int, val iode: Int, val toe: Double,
        val sqrtA: Double, val e: Double, val i0: Double, val omega0: Double,
        val omega: Double, val m0: Double, val deltaN: Double,
        val omegaDot: Double, val idot: Double,
        val cuc: Double, val cus: Double, val crc: Double, val crs: Double,
        val cic: Double, val cis: Double,
        val receivedAtMs: Long,
    ) {
        fun toJson(): JSONObject = JSONObject()
            .put("svid", svid).put("iode", iode).put("toe", toe)
            .put("sqrtA", sqrtA).put("e", e).put("i0", i0).put("Omega0", omega0)
            .put("omega", omega).put("M0", m0).put("dn", deltaN)
            .put("OmegaDot", omegaDot).put("IDOT", idot)
            .put("Cuc", cuc).put("Cus", cus).put("Crc", crc).put("Crs", crs)
            .put("Cic", cic).put("Cis", cis).put("rx", receivedAtMs)

        companion object {
            fun fromJson(o: JSONObject) = Ephemeris(
                o.getInt("svid"), o.getInt("iode"), o.getDouble("toe"),
                o.getDouble("sqrtA"), o.getDouble("e"), o.getDouble("i0"), o.getDouble("Omega0"),
                o.getDouble("omega"), o.getDouble("M0"), o.getDouble("dn"),
                o.getDouble("OmegaDot"), o.getDouble("IDOT"),
                o.getDouble("Cuc"), o.getDouble("Cus"), o.getDouble("Crc"), o.getDouble("Crs"),
                o.getDouble("Cic"), o.getDouble("Cis"), o.getLong("rx"),
            )
        }
    }

    private val sf2 = HashMap<Int, BooleanArray>()
    private val sf3 = HashMap<Int, BooleanArray>()
    var subframesOk = 0; private set
    var subframesBad = 0; private set

    /** Feed one GPS L1 C/A subframe. Returns a new ephemeris when subframes 2 and 3 pair up. */
    fun onSubframe(svid: Int, data: ByteArray, nowMs: Long): Ephemeris? {
        if (data.size < 40) return null
        val bits = recover(data)
        if (bits == null) { subframesBad++; return null }
        subframesOk++
        when (field(bits, 50, 3).toInt()) {          // subframe ID: HOW bits 20-22
            2 -> sf2[svid] = bits
            3 -> sf3[svid] = bits
            else -> return null
        }
        val a = sf2[svid] ?: return null
        val b = sf3[svid] ?: return null
        val iode2 = field(a, 61, 8).toInt()
        val iode3 = field(b, 271, 8).toInt()
        if (iode2 != iode3) return null
        return build(svid, a, b, nowMs)
    }

    private fun build(svid: Int, s2: BooleanArray, s3: BooleanArray, nowMs: Long): Ephemeris {
        val pi = PI_GPS
        return Ephemeris(
            svid = svid,
            iode = field(s2, 61, 8).toInt(),
            crs = signed(field(s2, 69, 16), 16) * P2(-5),
            deltaN = signed(field(s2, 91, 16), 16) * P2(-43) * pi,
            m0 = signed(join(s2, 107, 8, 121, 24), 32) * P2(-31) * pi,
            cuc = signed(field(s2, 151, 16), 16) * P2(-29),
            e = join(s2, 167, 8, 181, 24).toDouble() * P2(-33),
            cus = signed(field(s2, 211, 16), 16) * P2(-29),
            sqrtA = join(s2, 227, 8, 241, 24).toDouble() * P2(-19),
            toe = field(s2, 271, 16).toDouble() * 16.0,
            cic = signed(field(s3, 61, 16), 16) * P2(-29),
            omega0 = signed(join(s3, 77, 8, 91, 24), 32) * P2(-31) * pi,
            cis = signed(field(s3, 121, 16), 16) * P2(-29),
            i0 = signed(join(s3, 137, 8, 151, 24), 32) * P2(-31) * pi,
            crc = signed(field(s3, 181, 16), 16) * P2(-5),
            omega = signed(join(s3, 197, 8, 211, 24), 32) * P2(-31) * pi,
            omegaDot = signed(field(s3, 241, 24), 24) * P2(-43) * pi,
            idot = signed(field(s3, 279, 14), 14) * P2(-43) * pi,
            receivedAtMs = nowMs,
        )
    }

    companion object {
        const val PI_GPS = 3.1415926535898
        private fun P2(n: Int) = Math.scalb(1.0, n)

        // Parity masks over d1..d24 (d1 = bit 23 of the 24-bit data value), IS-GPS-200 Table 20-XIV.
        private fun mask(vararg idx: Int) = idx.fold(0) { m, i -> m or (1 shl (24 - i)) }
        private val M25 = mask(1, 2, 3, 5, 6, 10, 11, 12, 13, 14, 17, 18, 20, 23)
        private val M26 = mask(2, 3, 4, 6, 7, 11, 12, 13, 14, 15, 18, 19, 21, 24)
        private val M27 = mask(1, 3, 4, 5, 7, 8, 12, 13, 14, 15, 16, 19, 20, 22)
        private val M28 = mask(2, 4, 5, 6, 8, 9, 13, 14, 15, 16, 17, 20, 21, 23)
        private val M29 = mask(1, 3, 5, 6, 7, 9, 10, 14, 15, 16, 17, 18, 21, 22, 24)
        private val M30 = mask(3, 5, 6, 8, 9, 10, 11, 13, 15, 19, 22, 23, 24)

        private fun par(x: Int) = Integer.bitCount(x) and 1

        /** Six parity bits (D25 as MSB) for source data d with previous D29*, D30*. */
        fun parity(d: Int, d29: Int, d30: Int): Int =
            ((d29 xor par(d and M25)) shl 5) or
            ((d30 xor par(d and M26)) shl 4) or
            ((d29 xor par(d and M27)) shl 3) or
            ((d30 xor par(d and M28)) shl 2) or
            ((d30 xor par(d and M29)) shl 1) or
            (d29 xor par(d and M30))

        /** Returns 1-indexed subframe bits (data bits recovered), or null if parity fails. */
        fun recover(data: ByteArray): BooleanArray? {
            val raw = IntArray(10) { w ->
                ((data[4 * w].toInt() and 0xFF) shl 24 or
                 ((data[4 * w + 1].toInt() and 0xFF) shl 16) or
                 ((data[4 * w + 2].toInt() and 0xFF) shl 8) or
                 (data[4 * w + 3].toInt() and 0xFF)) and 0x3FFFFFFF
            }
            for (alreadyDeInverted in booleanArrayOf(false, true)) {
                val words = decodeWords(raw, alreadyDeInverted) ?: continue
                val bits = BooleanArray(301)
                for (w in 0 until 10) for (k in 0 until 24) {
                    bits[30 * w + 1 + k] = (words[w] shr (23 - k)) and 1 == 1
                }
                return bits
            }
            return null
        }

        private fun decodeWords(raw: IntArray, deInverted: Boolean): IntArray? {
            val out = IntArray(10)
            // Word 1 (TLM): previous D29*/D30* unknown, so try all four and require the preamble.
            var tlmOk = false
            loop@ for (p29 in 0..1) for (p30 in 0..1) {
                val d = dataBits(raw[0], p30, deInverted)
                if (d shr 16 == 0x8B && parity(d, p29, p30) == raw[0] and 0x3F) {
                    out[0] = d; tlmOk = true; break@loop
                }
            }
            if (!tlmOk) return null
            for (w in 1 until 10) {
                val p29 = (raw[w - 1] shr 1) and 1
                val p30 = raw[w - 1] and 1
                val d = dataBits(raw[w], p30, deInverted)
                if (parity(d, p29, p30) != raw[w] and 0x3F) return null
                out[w] = d
            }
            return out
        }

        private fun dataBits(word: Int, prevD30: Int, deInverted: Boolean): Int {
            val d = (word shr 6) and 0xFFFFFF
            return if (!deInverted && prevD30 == 1) d xor 0xFFFFFF else d
        }

        fun field(bits: BooleanArray, start: Int, len: Int): Long {
            var v = 0L
            for (i in start until start + len) v = (v shl 1) or (if (bits[i]) 1L else 0L)
            return v
        }

        private fun join(bits: BooleanArray, s1: Int, l1: Int, s2: Int, l2: Int): Long =
            (field(bits, s1, l1) shl l2) or field(bits, s2, l2)

        private fun signed(v: Long, len: Int): Double =
            (if (v and (1L shl (len - 1)) != 0L) v - (1L shl len) else v).toDouble()
    }
}
