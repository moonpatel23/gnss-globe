package com.moon.gnssglobe

import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Same-origin proxy for the page's online data (weather, warnings, aviation).
 *
 * The page asks for  https://appassets.androidplatform.net/proxy/https/<host>/<path>?<query>
 * and this fetches https://<host>/<path>?<query> from the network. Because the answer comes from
 * the page's own origin, browser cross-origin rules (which many government servers don't cater
 * for) never apply, and a proper User-Agent can be sent (api.weather.gov requires one).
 *
 * Data files (not map tiles) are also kept on disk: when the network fails the last good copy is
 * returned with an "X-Proxy-Cache" header giving its age, so layers still show offline.
 * Only the hosts listed in [HOSTS] can be reached.
 */
class WebProxy(cacheRoot: File) {

    private val dir = File(cacheRoot, "proxy").apply { mkdirs() }

    fun handles(uri: Uri): Boolean =
        uri.host == "appassets.androidplatform.net" && uri.encodedPath?.startsWith("/proxy/") == true

    fun handle(uri: Uri): WebResourceResponse {
        val p = uri.encodedPath!!.removePrefix("/proxy/")
        val scheme = p.substringBefore('/')
        val rest = p.substringAfter('/', "")
        val host = rest.substringBefore('/')
        if (scheme != "https" && scheme != "http") return error(400, "bad scheme")
        if (host !in HOSTS) return error(403, "host not allowed: $host")
        val target = "$scheme://$rest" + (uri.encodedQuery?.let { "?$it" } ?: "")
        val isTile = Regex("""\.(png|jpe?g|webp)$""", RegexOption.IGNORE_CASE).containsMatchIn(rest)
        val cacheFile = File(dir, sha1(target))
        try {
            val c = URL(target).openConnection() as HttpURLConnection
            c.connectTimeout = 15_000; c.readTimeout = 30_000
            c.setRequestProperty("User-Agent", USER_AGENT)
            c.setRequestProperty("Accept", "*/*")
            try {
                val code = c.responseCode
                val type = c.contentType ?: guessType(rest)
                val body = (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes() } ?: ByteArray(0)
                if (code == 200 && !isTile) runCatching { cacheFile.writeBytes(body) }
                if (code != 200 && !isTile && cacheFile.exists()) return cached(cacheFile, rest)
                return response(code, type, body, mapOf("Cache-Control" to if (isTile) "max-age=300" else "no-store"))
            } finally { c.disconnect() }
        } catch (e: Exception) {
            if (!isTile && cacheFile.exists()) return cached(cacheFile, rest)
            return error(502, e.javaClass.simpleName + ": " + (e.message ?: ""))
        }
    }

    private fun cached(f: File, path: String) =
        response(200, guessType(path), f.readBytes(), mapOf("X-Proxy-Cache" to "${f.lastModified()}", "Cache-Control" to "no-store"))

    private fun error(code: Int, msg: String) = response(code, "text/plain", msg.toByteArray(), emptyMap())

    private fun response(code: Int, contentType: String, body: ByteArray, extra: Map<String, String>): WebResourceResponse {
        val mime = contentType.substringBefore(';').trim().ifEmpty { "application/octet-stream" }
        val charset = Regex("charset=([^;]+)").find(contentType)?.groupValues?.get(1)?.trim()
        // WebResourceResponse rejects redirect codes and needs a non-empty reason phrase.
        val status = if (code in 300..399 || code < 100 || code > 599) 502 else code
        val headers = HashMap(extra)
        headers["Access-Control-Allow-Origin"] = "*"
        headers["Access-Control-Expose-Headers"] = "X-Proxy-Cache"
        return WebResourceResponse(mime, charset, status, if (status == 200) "OK" else "Error",
            headers, ByteArrayInputStream(body))
    }

    private fun guessType(path: String): String = when {
        path.endsWith(".png", true) -> "image/png"
        path.endsWith(".jpg", true) || path.endsWith(".jpeg", true) -> "image/jpeg"
        path.endsWith(".kmz", true) -> "application/vnd.google-earth.kmz"
        path.endsWith(".kml", true) -> "application/vnd.google-earth.kml+xml"
        path.endsWith(".xml", true) -> "text/xml"
        else -> "application/json"
    }

    private fun sha1(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    companion object {
        const val USER_AGENT = "GNSS-Globe-Android (personal; github.com/moonpatel23/gnss-globe)"
        val HOSTS = setOf(
            "mesonet.agron.iastate.edu",                 // NEXRAD radar, HRRR forecast radar
            "api.weather.gov",                           // NWS warnings
            "msi.nga.mil",                               // NGA navigational warnings
            "www.nhc.noaa.gov", "nhc.noaa.gov",          // hurricanes
            "aviationweather.gov",                       // SIGMET / G-AIRMET / METAR
            "tfr.faa.gov",                               // TFRs
            "www.wpc.ncep.noaa.gov",                     // surface fronts
            "mapservices.weather.noaa.gov",
        )
    }
}
