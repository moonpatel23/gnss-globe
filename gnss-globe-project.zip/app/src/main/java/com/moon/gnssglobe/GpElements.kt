package com.moon.gnssglobe

import java.util.Calendar
import java.util.TimeZone

// CelesTrak general-perturbations (GP) element sets in two-line format. Pure Kotlin, unit-testable.
// These are the published orbital elements for every GNSS satellite; the page propagates them with
// SGP4 (satellite.js) to give km-level positions for constellations whose broadcast navigation
// messages the tablet does not decode (GLONASS, BeiDou, NavIC, and Galileo/QZSS before decoding).

data class GpRecord(
    val norad: Int, val name: String, val sys: Int,
    val line1: String, val line2: String, val epochMs: Long,
) {
    /** SGP4 elements stay usable for days; refreshed every 12 h when online, kept 14 days for offline use. */
    fun expiresMs(): Long = epochMs + 14 * 86_400_000L
}

object GpElements {
    const val URL_GNSS = "https://celestrak.org/NORAD/elements/gp.php?GROUP=gnss&FORMAT=tle"
    val URL_GROUPS = listOf("gps-ops", "glo-ops", "galileo", "beidou")
        .map { "https://celestrak.org/NORAD/elements/gp.php?GROUP=$it&FORMAT=tle" }

    /** Constellation from the CelesTrak object name, or null for objects we don't track. */
    fun systemOf(name: String): Int? {
        val n = name.uppercase()
        return when {
            n.startsWith("GPS") || n.contains("NAVSTAR") -> Sys.GPS
            n.startsWith("COSMOS") || n.contains("GLONASS") -> Sys.GLONASS
            n.startsWith("GSAT") || n.contains("GALILEO") -> Sys.GALILEO
            n.contains("BEIDOU") || n.contains("COMPASS") -> Sys.BEIDOU
            n.startsWith("QZS") || n.contains("MICHIBIKI") -> Sys.QZSS
            n.startsWith("IRNSS") || n.startsWith("NVS") -> Sys.NAVIC
            else -> null
        }
    }

    /** TLE line checksum: digits summed, '-' counts 1, mod 10, must equal column 69. */
    fun checksumOk(line: String): Boolean {
        if (line.length < 69) return false
        var sum = 0
        for (c in line.substring(0, 68)) {
            if (c.isDigit()) sum += c - '0' else if (c == '-') sum += 1
        }
        return line[68].isDigit() && sum % 10 == line[68] - '0'
    }

    /** Epoch from line 1 columns 19-32: two-digit year + fractional day of year (UTC). */
    fun epochMs(line1: String): Long {
        val yy = line1.substring(18, 20).trim().toInt()
        val doy = line1.substring(20, 32).trim().toDouble()
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        cal.clear()
        cal.set(if (yy < 57) 2000 + yy else 1900 + yy, Calendar.JANUARY, 1, 0, 0, 0)
        return cal.timeInMillis + Math.round((doy - 1.0) * 86_400_000.0)
    }

    /** Parses 3-line (name + two lines) TLE text; skips anything malformed or not a GNSS satellite. */
    fun parse(text: String): List<GpRecord> {
        val lines = text.lines().map { it.trimEnd() }.filter { it.isNotEmpty() }
        val out = ArrayList<GpRecord>()
        var i = 0
        while (i + 2 < lines.size) {
            val name = lines[i].trim()
            val l1 = lines[i + 1]; val l2 = lines[i + 2]
            if (l1.startsWith("1 ") && l2.startsWith("2 ") && checksumOk(l1) && checksumOk(l2)) {
                val sys = systemOf(name)
                val norad = l1.substring(2, 7).trim().toIntOrNull()
                if (sys != null && norad != null) out.add(GpRecord(norad, name, sys, l1, l2, epochMs(l1)))
                i += 3
            } else {
                i += 1   // resynchronise on the next name line
            }
        }
        return out
    }
}
