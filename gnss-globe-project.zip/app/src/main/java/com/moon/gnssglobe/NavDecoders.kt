package com.moon.gnssglobe

// Pure-Kotlin navigation-message decoders (no Android imports, so they can be unit-tested on a JVM).
//
//  LnavDecoder        GPS / QZSS L1 C/A LNAV: subframe 1 (clock, health, week), 2-3 (ephemeris),
//                     4-5 (GPS almanac, all satellites).                                IS-GPS-200
//  GalileoInavDecoder Galileo E1-B I/NAV: word types 1-4 (ephemeris + clock), 5 (health). OS SIS ICD
//
// All times are kept as GPS-time seconds since 1980-01-06 00:00 ("absolute GPS seconds").
// Galileo System Time is aligned to GPS time, so the same scale is used for it.

/** Android GnssStatus constellation types. */
object Sys {
    const val GPS = 1; const val SBAS = 2; const val GLONASS = 3; const val QZSS = 4
    const val BEIDOU = 5; const val GALILEO = 6; const val NAVIC = 7
}

object GnssTime {
    const val GPS_EPOCH_UNIX = 315_964_800.0
    const val LEAP_SECONDS = 18.0           // GPS - UTC
    const val WEEK = 604_800.0

    fun gpsAbs(utcMs: Long): Double = utcMs / 1000.0 - GPS_EPOCH_UNIX + LEAP_SECONDS
    fun utcMs(gpsAbs: Double): Long = ((gpsAbs + GPS_EPOCH_UNIX - LEAP_SECONDS) * 1000.0).toLong()

    /** Seconds-of-week value placed in the week that puts it closest to [nowAbs]. */
    fun nearest(sow: Double, nowAbs: Double): Double {
        val week = Math.floor(nowAbs / WEEK)
        var t = week * WEEK + sow
        if (t - nowAbs > WEEK / 2) t -= WEEK
        if (nowAbs - t > WEEK / 2) t += WEEK
        return t
    }

    /** Full week number from a truncated one (e.g. 10-bit GPS WN, 8-bit almanac WNa), nearest to now. */
    fun resolveWeek(truncated: Int, modulus: Int, nowAbs: Double): Int {
        val cur = Math.floor(nowAbs / WEEK).toInt()
        var diff = Math.floorMod(truncated - cur, modulus)
        if (diff > modulus / 2) diff -= modulus
        return cur + diff
    }
}

/** Keplerian broadcast ephemeris + clock (GPS/QZSS LNAV or Galileo I/NAV). Angles in radians. */
data class KeplerEph(
    val sys: Int, val svid: Int, val iod: Int,
    val toeAbs: Double, val sqrtA: Double, val e: Double, val i0: Double, val omega0: Double,
    val omega: Double, val m0: Double, val deltaN: Double, val omegaDot: Double, val idot: Double,
    val cuc: Double, val cus: Double, val crc: Double, val crs: Double, val cic: Double, val cis: Double,
    val hasClock: Boolean = false, val tocAbs: Double = 0.0,
    val af0: Double = 0.0, val af1: Double = 0.0, val af2: Double = 0.0, val tgd: Double = 0.0,
    val health: Int = 0, val ura: Int = -1, val week: Int = -1,
    val receivedMs: Long = 0L,
) {
    /** Broadcast ephemeris is fitted for about 4 h; drawing keeps it 4 h past toe. */
    fun expiresMs(): Long = GnssTime.utcMs(toeAbs + 4 * 3600.0)
}

/** Almanac (reduced Keplerian set). Angles in radians. */
data class KeplerAlm(
    val sys: Int, val svid: Int, val toaAbs: Double,
    val sqrtA: Double, val e: Double, val i: Double, val omega0: Double, val omegaDot: Double,
    val omega: Double, val m0: Double, val af0: Double, val af1: Double, val health: Int,
    val receivedMs: Long = 0L,
) {
    /** Almanacs degrade slowly (km after days); keep them two weeks past their reference time. */
    fun expiresMs(): Long = GnssTime.utcMs(toaAbs + 14 * 86400.0)
}

private const val PI_GPS = 3.1415926535898
private fun p2(n: Int) = Math.scalb(1.0, n)

/** 1-indexed bit array helpers shared by both decoders. */
internal object Bits {
    fun field(bits: BooleanArray, start: Int, len: Int): Long {
        var v = 0L
        for (i in start until start + len) v = (v shl 1) or (if (bits[i]) 1L else 0L)
        return v
    }
    fun join(bits: BooleanArray, s1: Int, l1: Int, s2: Int, l2: Int): Long =
        (field(bits, s1, l1) shl l2) or field(bits, s2, l2)
    fun signed(v: Long, len: Int): Double =
        (if (v and (1L shl (len - 1)) != 0L) v - (1L shl len) else v).toDouble()
    fun sfield(bits: BooleanArray, start: Int, len: Int) = signed(field(bits, start, len), len)
    fun ufield(bits: BooleanArray, start: Int, len: Int) = field(bits, start, len).toDouble()

    /** Bytes (MSB first) to a 1-indexed bit array of [count] bits. */
    fun fromBytes(data: ByteArray, count: Int): BooleanArray {
        val out = BooleanArray(count + 1)
        for (i in 0 until count) {
            val b = data[i / 8].toInt() and 0xFF
            out[i + 1] = (b shr (7 - i % 8)) and 1 == 1
        }
        return out
    }
}

// ------------------------------------------------------------------------------------------------
// GPS / QZSS LNAV
// ------------------------------------------------------------------------------------------------

class LnavDecoder(private val sys: Int) {

    class Result(val eph: KeplerEph? = null, val alms: List<KeplerAlm> = emptyList())

    private class Sf1(val iodc: Int, val week10: Int, val ura: Int, val health: Int,
                      val tgd: Double, val toc: Double, val af2: Double, val af1: Double, val af0: Double)

    private val sf1 = HashMap<Int, Sf1>()
    private val sf2 = HashMap<Int, BooleanArray>()
    private val sf3 = HashMap<Int, BooleanArray>()
    private val pendingAlm = HashMap<Int, BooleanArray>()   // almanac pages waiting for WNa
    private var wna: Int = -1; private var wnaToa: Int = -1
    var subframesOk = 0; private set
    var subframesBad = 0; private set

    /** Feed one 40-byte subframe as Android delivers it. */
    fun onSubframe(svid: Int, data: ByteArray, nowMs: Long): Result {
        if (data.size < 40) return Result()
        val bits = recover(data)
        if (bits == null) { subframesBad++; return Result() }
        subframesOk++
        val nowAbs = GnssTime.gpsAbs(nowMs)
        return when (Bits.field(bits, 50, 3).toInt()) {     // subframe ID: HOW bits 20-22
            1 -> { sf1[svid] = parseSf1(bits); Result(tryEph(svid, nowAbs, nowMs)) }
            2 -> { sf2[svid] = bits; Result(tryEph(svid, nowAbs, nowMs)) }
            3 -> { sf3[svid] = bits; Result(tryEph(svid, nowAbs, nowMs)) }
            4, 5 -> Result(alms = if (sys == Sys.GPS) almanacPage(bits, nowAbs, nowMs) else emptyList())
            else -> Result()
        }
    }

    private fun parseSf1(b: BooleanArray) = Sf1(
        iodc = ((Bits.field(b, 83, 2) shl 8) or Bits.field(b, 211, 8)).toInt(),
        week10 = Bits.field(b, 61, 10).toInt(),
        ura = Bits.field(b, 73, 4).toInt(),
        health = Bits.field(b, 77, 6).toInt(),
        tgd = Bits.sfield(b, 197, 8) * p2(-31),
        toc = Bits.ufield(b, 219, 16) * 16.0,
        af2 = Bits.sfield(b, 241, 8) * p2(-55),
        af1 = Bits.sfield(b, 249, 16) * p2(-43),
        af0 = Bits.sfield(b, 271, 22) * p2(-31),
    )

    private fun tryEph(svid: Int, nowAbs: Double, nowMs: Long): KeplerEph? {
        val s2 = sf2[svid] ?: return null
        val s3 = sf3[svid] ?: return null
        val iode = Bits.field(s2, 61, 8).toInt()
        if (iode != Bits.field(s3, 271, 8).toInt()) return null
        val c = sf1[svid]?.takeIf { (it.iodc and 0xFF) == iode }
        val f = Bits
        return KeplerEph(
            sys = sys, svid = svid, iod = iode,
            toeAbs = GnssTime.nearest(f.ufield(s2, 271, 16) * 16.0, nowAbs),
            crs = f.sfield(s2, 69, 16) * p2(-5),
            deltaN = f.sfield(s2, 91, 16) * p2(-43) * PI_GPS,
            m0 = f.signed(f.join(s2, 107, 8, 121, 24), 32) * p2(-31) * PI_GPS,
            cuc = f.sfield(s2, 151, 16) * p2(-29),
            e = f.join(s2, 167, 8, 181, 24).toDouble() * p2(-33),
            cus = f.sfield(s2, 211, 16) * p2(-29),
            sqrtA = f.join(s2, 227, 8, 241, 24).toDouble() * p2(-19),
            cic = f.sfield(s3, 61, 16) * p2(-29),
            omega0 = f.signed(f.join(s3, 77, 8, 91, 24), 32) * p2(-31) * PI_GPS,
            cis = f.sfield(s3, 121, 16) * p2(-29),
            i0 = f.signed(f.join(s3, 137, 8, 151, 24), 32) * p2(-31) * PI_GPS,
            crc = f.sfield(s3, 181, 16) * p2(-5),
            omega = f.signed(f.join(s3, 197, 8, 211, 24), 32) * p2(-31) * PI_GPS,
            omegaDot = f.sfield(s3, 241, 24) * p2(-43) * PI_GPS,
            idot = f.sfield(s3, 279, 14) * p2(-43) * PI_GPS,
            hasClock = c != null,
            tocAbs = if (c != null) GnssTime.nearest(c.toc, nowAbs) else 0.0,
            af0 = c?.af0 ?: 0.0, af1 = c?.af1 ?: 0.0, af2 = c?.af2 ?: 0.0, tgd = c?.tgd ?: 0.0,
            health = c?.health ?: 0, ura = c?.ura ?: -1,
            week = if (c != null) GnssTime.resolveWeek(c.week10, 1024, nowAbs) else -1,
            receivedMs = nowMs,
        )
    }

    /** Subframes 4 and 5: almanac pages carry SV IDs 1-32; subframe 5 page 25 (SV ID 51) carries toa/WNa. */
    private fun almanacPage(b: BooleanArray, nowAbs: Double, nowMs: Long): List<KeplerAlm> {
        val dataId = Bits.field(b, 61, 2).toInt()
        val svId = Bits.field(b, 63, 6).toInt()
        if (dataId != 1) return emptyList()
        if (svId == 51) {
            wnaToa = Bits.field(b, 69, 8).toInt()
            wna = Bits.field(b, 77, 8).toInt()
            val out = pendingAlm.mapNotNull { (sv, bits) -> parseAlm(sv, bits, nowAbs, nowMs) }
            pendingAlm.clear()
            return out
        }
        if (svId !in 1..32) return emptyList()
        if (wna < 0) { pendingAlm[svId] = b; return emptyList() }
        return listOfNotNull(parseAlm(svId, b, nowAbs, nowMs))
    }

    private fun parseAlm(svId: Int, b: BooleanArray, nowAbs: Double, nowMs: Long): KeplerAlm? {
        val sqrtA = Bits.ufield(b, 151, 24) * p2(-11)
        val e = Bits.ufield(b, 69, 16) * p2(-21)
        if (sqrtA !in 5000.0..5300.0 || e > 0.05) return null      // dummy / unused PRN page
        val toa = Bits.ufield(b, 91, 8) * 4096.0
        val week = GnssTime.resolveWeek(wna, 256, nowAbs)
        val af0 = Bits.signed((Bits.field(b, 271, 8) shl 3) or Bits.field(b, 290, 3), 11) * p2(-20)
        return KeplerAlm(
            sys = sys, svid = svId, toaAbs = week * GnssTime.WEEK + toa,
            sqrtA = sqrtA, e = e,
            i = (0.30 + Bits.sfield(b, 99, 16) * p2(-19)) * PI_GPS,
            omegaDot = Bits.sfield(b, 121, 16) * p2(-38) * PI_GPS,
            health = Bits.field(b, 137, 8).toInt(),
            omega0 = Bits.sfield(b, 181, 24) * p2(-23) * PI_GPS,
            omega = Bits.sfield(b, 211, 24) * p2(-23) * PI_GPS,
            m0 = Bits.sfield(b, 241, 24) * p2(-23) * PI_GPS,
            af0 = af0, af1 = Bits.sfield(b, 279, 11) * p2(-38),
            receivedMs = nowMs,
        )
    }

    companion object {
        // Parity masks over d1..d24 (d1 = bit 23 of the 24-bit data value), IS-GPS-200 Table 20-XIV.
        private fun mask(vararg idx: Int) = idx.fold(0) { m, i -> m or (1 shl (24 - i)) }
        private val M25 = mask(1, 2, 3, 5, 6, 10, 11, 12, 13, 14, 17, 18, 20, 23)
        private val M26 = mask(2, 3, 4, 6, 7, 11, 12, 13, 14, 15, 18, 19, 21, 24)
        private val M27 = mask(1, 3, 4, 5, 7, 8, 12, 13, 14, 15, 16, 19, 20, 22)
        private val M28 = mask(2, 4, 5, 6, 8, 9, 13, 14, 15, 16, 17, 20, 21, 23)
        private val M29 = mask(1, 3, 5, 6, 7, 9, 10, 14, 15, 16, 17, 18, 21, 22, 24)
        private val M30 = mask(3, 5, 6, 8, 9, 10, 11, 13, 15, 19, 22, 23, 24)
        private fun par(x: Int) = Integer.bitCount(x) and 1

        /** Six parity bits (D25 as MSB) for source data d with previous D29*, D30*. */
        fun parity(d: Int, d29: Int, d30: Int): Int =
            ((d29 xor par(d and M25)) shl 5) or
            ((d30 xor par(d and M26)) shl 4) or
            ((d29 xor par(d and M27)) shl 3) or
            ((d30 xor par(d and M28)) shl 2) or
            ((d30 xor par(d and M29)) shl 1) or
            (d29 xor par(d and M30))

        /**
         * Android packs each 30-bit word into the low 30 bits of 4 bytes, MSB first. Some chips deliver
         * D1-D24 as transmitted (inverted when the previous D30 is 1), others already de-inverted, so both
         * are tried. Returns 1-indexed subframe bits with data recovered, or null if any parity fails.
         */
        fun recover(data: ByteArray): BooleanArray? {
            val raw = IntArray(10) { w ->
                ((data[4 * w].toInt() and 0xFF) shl 24 or
                 ((data[4 * w + 1].toInt() and 0xFF) shl 16) or
                 ((data[4 * w + 2].toInt() and 0xFF) shl 8) or
                 (data[4 * w + 3].toInt() and 0xFF)) and 0x3FFFFFFF
            }
            for (alreadyDeInverted in booleanArrayOf(false, true)) {
                val words = decodeWords(raw, alreadyDeInverted) ?: continue
                val bits = BooleanArray(301)
                for (w in 0 until 10) for (k in 0 until 24) {
                    bits[30 * w + 1 + k] = (words[w] shr (23 - k)) and 1 == 1
                }
                return bits
            }
            return null
        }

        private fun decodeWords(raw: IntArray, deInverted: Boolean): IntArray? {
            val out = IntArray(10)
            var tlmOk = false
            loop@ for (p29 in 0..1) for (p30 in 0..1) {
                val d = dataBits(raw[0], p30, deInverted)
                if (d shr 16 == 0x8B && parity(d, p29, p30) == raw[0] and 0x3F) {
                    out[0] = d; tlmOk = true; break@loop
                }
            }
            if (!tlmOk) return null
            for (w in 1 until 10) {
                val p29 = (raw[w - 1] shr 1) and 1
                val p30 = raw[w - 1] and 1
                val d = dataBits(raw[w], p30, deInverted)
                if (parity(d, p29, p30) != raw[w] and 0x3F) return null
                out[w] = d
            }
            return out
        }

        private fun dataBits(word: Int, prevD30: Int, deInverted: Boolean): Int {
            val d = (word shr 6) and 0xFFFFFF
            return if (!deInverted && prevD30 == 1) d xor 0xFFFFFF else d
        }
    }
}

// ------------------------------------------------------------------------------------------------
// Galileo I/NAV (E1-B)
// ------------------------------------------------------------------------------------------------

/**
 * Android delivers one I/NAV page per message: the even and odd page parts, 2 x 114 bits (sync and
 * tail removed), packed MSB first into 29 bytes. Even part: E/O(1) type(1) data 1/2 (112).
 * Odd part: E/O(1) type(1) data 2/2 (16) OSNMA(40) SAR(22) spare(2) CRC(24) SSP(8).
 * The 128-bit word = data 1/2 + data 2/2; CRC-24Q covers bits 1-196.
 */
class GalileoInavDecoder {

    private class Words(val w: Array<BooleanArray?> = arrayOfNulls(5))
    private val words = HashMap<Int, Words>()
    private val health = HashMap<Int, Int>()
    var pagesOk = 0; private set
    var pagesBad = 0; private set

    fun onPage(svid: Int, data: ByteArray, nowMs: Long): KeplerEph? {
        if (data.size < 28) return null
        val p = Bits.fromBytes(data, minOf(data.size * 8, 232))
        if (crc24q(p, 196) != Bits.field(p, 197, 24).toInt()) { pagesBad++; return null }
        pagesOk++
        if (p[2] || p[116]) return null                  // alert page
        val w = BooleanArray(129)
        for (i in 0 until 112) w[1 + i] = p[3 + i]
        for (i in 0 until 16) w[113 + i] = p[117 + i]
        val type = Bits.field(w, 1, 6).toInt()
        when (type) {
            in 1..4 -> {
                val set = words.getOrPut(svid) { Words() }
                set.w[type] = w
                return tryEph(svid, set, GnssTime.gpsAbs(nowMs), nowMs)
            }
            5 -> {
                // E1-B signal health (2 bits) and data validity (1 bit): 0 = healthy.
                health[svid] = (Bits.field(w, 70, 2).toInt() shl 1) or Bits.field(w, 73, 1).toInt()
            }
        }
        return null
    }

    private fun tryEph(svid: Int, set: Words, nowAbs: Double, nowMs: Long): KeplerEph? {
        val w1 = set.w[1] ?: return null; val w2 = set.w[2] ?: return null
        val w3 = set.w[3] ?: return null; val w4 = set.w[4] ?: return null
        val iod = Bits.field(w1, 7, 10).toInt()
        if (listOf(w2, w3, w4).any { Bits.field(it, 7, 10).toInt() != iod }) return null
        val f = Bits
        return KeplerEph(
            sys = Sys.GALILEO, svid = svid, iod = iod,
            toeAbs = GnssTime.nearest(f.ufield(w1, 17, 14) * 60.0, nowAbs),
            m0 = f.sfield(w1, 31, 32) * p2(-31) * PI_GPS,
            e = f.ufield(w1, 63, 32) * p2(-33),
            sqrtA = f.ufield(w1, 95, 32) * p2(-19),
            omega0 = f.sfield(w2, 17, 32) * p2(-31) * PI_GPS,
            i0 = f.sfield(w2, 49, 32) * p2(-31) * PI_GPS,
            omega = f.sfield(w2, 81, 32) * p2(-31) * PI_GPS,
            idot = f.sfield(w2, 113, 14) * p2(-43) * PI_GPS,
            omegaDot = f.sfield(w3, 17, 24) * p2(-43) * PI_GPS,
            deltaN = f.sfield(w3, 41, 16) * p2(-43) * PI_GPS,
            cuc = f.sfield(w3, 57, 16) * p2(-29),
            cus = f.sfield(w3, 73, 16) * p2(-29),
            crc = f.sfield(w3, 89, 16) * p2(-5),
            crs = f.sfield(w3, 105, 16) * p2(-5),
            cic = f.sfield(w4, 23, 16) * p2(-29),
            cis = f.sfield(w4, 39, 16) * p2(-29),
            hasClock = true,
            tocAbs = GnssTime.nearest(f.ufield(w4, 55, 14) * 60.0, nowAbs),
            af0 = f.sfield(w4, 69, 31) * p2(-34),
            af1 = f.sfield(w4, 100, 21) * p2(-46),
            af2 = f.sfield(w4, 121, 6) * p2(-59),
            health = health[svid] ?: 0,
            receivedMs = nowMs,
        )
    }

    companion object {
        /** CRC-24Q (polynomial 0x1864CFB, init 0) over bits 1..n of a 1-indexed bit array. */
        fun crc24q(bits: BooleanArray, n: Int): Int {
            var crc = 0
            for (i in 1..n) {
                val top = ((crc shr 23) and 1) xor (if (bits[i]) 1 else 0)
                crc = (crc shl 1) and 0xFFFFFF
                if (top == 1) crc = crc xor 0x864CFB
            }
            return crc
        }
    }
}
