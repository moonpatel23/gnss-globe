package com.moon.gnssglobe

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.GnssNavigationMessage
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject

/**
 * One screen: a WebView running an offline Cesium globe.
 * Kotlin reads the tablet's own GNSS chip (satellite status, position, and raw GPS
 * navigation messages for the broadcast ephemeris) and pushes JSON to the page.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var lm: LocationManager
    private val main = Handler(Looper.getMainLooper())
    private var pageReady = false
    private var gnssStarted = false
    private var lastLoc: Location? = null
    private var lastStatus: GnssStatus? = null

    private val decoder = GpsLnavDecoder()
    private val ephemerides = HashMap<Int, GpsLnavDecoder.Ephemeris>()
    private var navMessages = 0
    private var navSupported: Boolean? = null

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        if (granted[Manifest.permission.ACCESS_FINE_LOCATION] == true) startGnss()
        else showMessage("Precise location permission is needed to read satellite data.")
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        loadEphemerisCache()

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)

            override fun onPageFinished(view: WebView, url: String) {
                pageReady = true
                if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    showMessage("Location is turned off. Turn it on in quick settings.")
                }
                push()
            }
        }
        setContentView(web)
        web.loadUrl("https://appassets.androidplatform.net/assets/web/index.html")

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED
        ) startGnss()
        else permLauncher.launch(arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    private val locListener = LocationListener { loc -> lastLoc = loc; push() }

    private val gnssCallback = object : GnssStatus.Callback() {
        override fun onSatelliteStatusChanged(status: GnssStatus) { lastStatus = status; push() }
    }

    private val navCallback = object : GnssNavigationMessage.Callback() {
        override fun onGnssNavigationMessageReceived(msg: GnssNavigationMessage) {
            if (msg.type != GnssNavigationMessage.TYPE_GPS_L1CA) return
            navMessages++
            navSupported = true
            val eph = decoder.onSubframe(msg.svid, msg.data, System.currentTimeMillis()) ?: return
            val old = ephemerides[eph.svid]
            if (old == null || old.iode != eph.iode || old.toe != eph.toe) {
                ephemerides[eph.svid] = eph
                saveEphemerisCache()
            }
        }

        @Deprecated("Deprecated in Android 12 but still reported by many chips")
        override fun onStatusChanged(status: Int) {
            if (status == GnssNavigationMessage.Callback.STATUS_NOT_SUPPORTED) navSupported = false
        }
    }

    @SuppressLint("MissingPermission")
    private fun startGnss() {
        if (gnssStarted) return
        gnssStarted = true
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener, Looper.getMainLooper())
        lm.registerGnssStatusCallback(gnssCallback, main)
        try {
            if (!lm.registerGnssNavigationMessageCallback(navCallback, main)) navSupported = false
        } catch (e: Exception) {
            navSupported = false
        }
        lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { lastLoc = it }
        push()
    }

    private fun finite(v: Float) = if (v.isFinite()) v.toDouble() else 0.0

    /** Sends the latest fix, satellite list and decoded ephemerides to the page. */
    private fun push() {
        if (!pageReady) return
        val sats = JSONArray()
        lastStatus?.let { s ->
            for (i in 0 until s.satelliteCount) {
                sats.put(JSONObject().apply {
                    put("c", s.getConstellationType(i))
                    put("id", s.getSvid(i))
                    put("az", finite(s.getAzimuthDegrees(i)))
                    put("el", finite(s.getElevationDegrees(i)))
                    put("cn0", finite(s.getCn0DbHz(i)))
                    put("used", s.usedInFix(i))
                    put("f", if (s.hasCarrierFrequencyHz(i)) finite(s.getCarrierFrequencyHz(i)) / 1e6 else 0.0)
                })
            }
        }
        val eph = JSONArray()
        ephemerides.values.forEach { eph.put(it.toJson()) }

        val payload = JSONObject()
            .put("sats", sats)
            .put("eph", eph)
            .put("now", System.currentTimeMillis())
            .put("nav", JSONObject()
                .put("supported", navSupported ?: JSONObject.NULL)
                .put("msgs", navMessages)
                .put("ok", decoder.subframesOk)
                .put("bad", decoder.subframesBad))
        lastLoc?.let { loc ->
            payload.put("lat", loc.latitude)
                .put("lon", loc.longitude)
                .put("alt", if (loc.hasAltitude()) loc.altitude else 0.0)
                .put("acc", if (loc.hasAccuracy()) loc.accuracy.toDouble() else -1.0)
                .put("utc", loc.time)
        }
        web.evaluateJavascript("window.updateGnss && window.updateGnss($payload)", null)
    }

    // Ephemerides stay usable for a few hours, so they are cached for offline restarts.
    private fun loadEphemerisCache() {
        val txt = getPreferences(MODE_PRIVATE).getString("eph", null) ?: return
        val now = System.currentTimeMillis()
        try {
            val arr = JSONArray(txt)
            for (i in 0 until arr.length()) {
                val e = GpsLnavDecoder.Ephemeris.fromJson(arr.getJSONObject(i))
                if (now - e.receivedAtMs < 4 * 3600_000L) ephemerides[e.svid] = e
            }
        } catch (e: Exception) { }
    }

    private fun saveEphemerisCache() {
        val arr = JSONArray()
        ephemerides.values.forEach { arr.put(it.toJson()) }
        getPreferences(MODE_PRIVATE).edit().putString("eph", arr.toString()).apply()
    }

    private fun showMessage(text: String) {
        if (!pageReady) return
        web.evaluateJavascript(
            "window.showMessage && window.showMessage(${JSONObject.quote(text)})", null)
    }

    override fun onDestroy() {
        if (gnssStarted) {
            lm.removeUpdates(locListener)
            lm.unregisterGnssStatusCallback(gnssCallback)
            lm.unregisterGnssNavigationMessageCallback(navCallback)
        }
        web.destroy()
        super.onDestroy()
    }
}
