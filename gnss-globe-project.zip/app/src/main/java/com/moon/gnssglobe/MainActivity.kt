package com.moon.gnssglobe

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Color
import android.widget.FrameLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.location.GnssMeasurementsEvent
import android.location.GnssNavigationMessage
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * One screen: a WebView running an offline Cesium globe.
 * Kotlin reads the tablet's own GNSS chip (satellite status, position, raw measurements and raw
 * navigation messages), decodes broadcast ephemeris/almanac, keeps valid orbit data in an on-tablet
 * SQLite database (OrbitDb), downloads CelesTrak elements when online, and pushes JSON to the page.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var lm: LocationManager
    private val main = Handler(Looper.getMainLooper())
    private var pageReady = false
    private var gnssStarted = false
    private var lastLoc: Location? = null
    private var lastStatus: GnssStatus? = null

    // Navigation-message decoders, one per signal type.
    private val lnavGps = LnavDecoder(Sys.GPS)
    private val lnavQzss = LnavDecoder(Sys.QZSS)
    private val galInav = GalileoInavDecoder()
    private val bdsD1 = BeidouD1Decoder()
    private val glo = GlonassDecoder()
    private var bdsD2Seen = 0
    private var navMessages = 0
    private var navSupported: Boolean? = null
    private val navTypesSeen = sortedSetOf<String>()

    // Orbit database: all writes and downloads on one background thread.
    private lateinit var db: OrbitDb
    private val io = Executors.newSingleThreadExecutor()
    private var orbitPushPending = false
    private var gpStatus = "not downloaded yet"
    private var gpBusy = false
    private val periodic = object : Runnable {
        override fun run() { io.execute { maintenance(false) }; main.postDelayed(this, 10 * 60_000L) }
    }
    // Latest raw measurements: these carry the signal code (C = L1 C/A, L = L1C, ...) that
    // GnssStatus lacks, so two signals on the same frequency can be told apart.
    private var lastMeas = JSONArray()
    private var lastMeasMs = 0L

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        if (granted[Manifest.permission.ACCESS_FINE_LOCATION] == true) startGnss()
        else showMessage("Precise location permission is needed to read satellite data.")
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        db = OrbitDb(this)
        getPreferences(MODE_PRIVATE).edit().remove("eph").apply()   // old cache, replaced by OrbitDb
        gpStatus = db.meta("gp_status") ?: gpStatus

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        val proxy = WebProxy(cacheDir)    // weather, warnings and aviation data for the page

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? =
                if (request.method == "GET" && proxy.handles(request.url)) proxy.handle(request.url)
                else loader.shouldInterceptRequest(request.url)

            override fun onPageFinished(view: WebView, url: String) {
                pageReady = true
                val cfg = JSONObject()
                    .put("catalogUrl", BuildConfig.CATALOG_URL)
                    .put("channel", BuildConfig.CHANNEL)
                    .put("version", BuildConfig.VERSION_NAME)
                web.evaluateJavascript("window.setConfig && window.setConfig($cfg)", null)
                if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    showMessage("Location is turned off. Turn it on in quick settings.")
                }
                push()
                pushOrbits()
            }
        }
        // Keep the page clear of the status bar, navigation bar and camera cutout
        // (Android 15 draws apps edge-to-edge), in full screen or a pop-up window.
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        root.addView(web, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }
        setContentView(root)
        web.loadUrl("https://appassets.androidplatform.net/assets/web/index.html")

        main.post(periodic)          // purge expired rows now and every 10 min; fetch CelesTrak when due

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED
        ) startGnss()
        else permLauncher.launch(arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    private val locListener = LocationListener { loc -> lastLoc = loc; push() }

    private val gnssCallback = object : GnssStatus.Callback() {
        override fun onSatelliteStatusChanged(status: GnssStatus) { lastStatus = status; push() }
    }

    private val navCallback = object : GnssNavigationMessage.Callback() {
        override fun onGnssNavigationMessageReceived(msg: GnssNavigationMessage) {
            navMessages++
            navSupported = true
            val now = System.currentTimeMillis()
            val data = msg.data ?: return
            when (msg.type) {
                GnssNavigationMessage.TYPE_GPS_L1CA -> {
                    navTypesSeen.add("GPS L1 C/A")
                    store(lnavGps.onSubframe(msg.svid, data, now))
                }
                GnssNavigationMessage.TYPE_QZS_L1CA -> {
                    navTypesSeen.add("QZSS L1 C/A")
                    store(lnavQzss.onSubframe(msg.svid, data, now))
                }
                GnssNavigationMessage.TYPE_GAL_I -> {
                    navTypesSeen.add("Galileo I/NAV")
                    galInav.onPage(msg.svid, data, now)?.let { store(LnavDecoder.Result(eph = it)) }
                }
                GnssNavigationMessage.TYPE_GLO_L1CA -> {
                    navTypesSeen.add("GLONASS L1 C/A")
                    glo.onString(msg.svid, data, now, msg.messageId, msg.submessageId)?.let { store(LnavDecoder.Result(eph = it)) }
                }
                GnssNavigationMessage.TYPE_BDS_D1 -> {
                    navTypesSeen.add("BeiDou D1")
                    bdsD1.onSubframe(msg.svid, data, now)?.let { store(LnavDecoder.Result(eph = it)) }
                }
                // D2 comes from the GEO satellites: a different page layout, not decoded (CelesTrak covers them).
                GnssNavigationMessage.TYPE_BDS_D2 -> { navTypesSeen.add("BeiDou D2 (GEO)"); bdsD2Seen++ }
                else -> navTypesSeen.add("type 0x" + Integer.toHexString(msg.type))
            }
        }

        @Deprecated("Deprecated in Android 12 but still reported by many chips")
        override fun onStatusChanged(status: Int) {
            if (status == GnssNavigationMessage.Callback.STATUS_NOT_SUPPORTED) navSupported = false
        }
    }

    /** Saves newly decoded orbit data on the background thread and refreshes the page if anything changed. */
    private fun store(r: LnavDecoder.Result) {
        if (r.eph == null && r.alms.isEmpty()) return
        io.execute {
            var changed = r.eph?.let { db.putEph(it) } ?: false
            for (a in r.alms) changed = db.putAlm(a) || changed
            if (changed) main.post { pushOrbits() }
        }
    }

    /** Purges expired rows; downloads CelesTrak elements every 12 h (hourly while none are stored). */
    private fun maintenance(force: Boolean) {
        val now = System.currentTimeMillis()
        var changed = db.purge(now) > 0
        val last = db.meta("gp_attempt")?.toLongOrNull() ?: 0L
        val due = if (db.count("gp") == 0) 3_600_000L else 12 * 3_600_000L
        if ((force && now - last > 120_000L) || now - last > due) {
            db.setMeta("gp_attempt", "$now")
            main.post { gpBusy = true; pushOrbits() }
            gpStatus = try {
                val list = OrbitDb.downloadGp()
                if (list.isEmpty()) "download returned no satellites" else {
                    db.replaceGp(list); changed = true
                    "downloaded ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(java.util.Date(now))} (${list.size} satellites)"
                }
            } catch (e: Exception) {
                "download failed: ${e.javaClass.simpleName}${e.message?.let { " – $it" } ?: ""}"
            }
            db.setMeta("gp_status", gpStatus)
            main.post { gpBusy = false; pushOrbits() }
        } else if (changed) main.post { pushOrbits() }
    }

    /** Sends the database contents to the page (throttled; they change rarely). */
    private fun pushOrbits() {
        if (!pageReady || orbitPushPending) return
        orbitPushPending = true
        main.postDelayed({
            orbitPushPending = false
            io.execute {
                val payload = JSONObject()
                    .put("eph", db.ephJson()).put("alm", db.almJson()).put("gp", db.gpJson())
                    .put("status", JSONObject()
                        .put("gp", if (gpBusy) "downloading…" else gpStatus)
                        .put("counts", JSONObject().put("eph", db.count("eph")).put("alm", db.count("alm")).put("gp", db.count("gp"))))
                main.post { web.evaluateJavascript("window.setOrbitData && window.setOrbitData($payload)", null) }
            }
        }, 500)
    }

    /** Called from the settings page. */
    inner class Bridge {
        @JavascriptInterface fun refreshOrbits() { io.execute { maintenance(true) } }
        @JavascriptInterface fun clearOrbitData() { io.execute { db.clearAll(); gpStatus = "cleared"; main.post { pushOrbits() } } }
    }

    private val measCallback = object : GnssMeasurementsEvent.Callback() {
        override fun onGnssMeasurementsReceived(event: GnssMeasurementsEvent) {
            val arr = JSONArray()
            for (m in event.measurements) {
                arr.put(JSONObject().apply {
                    put("c", m.constellationType)
                    put("id", m.svid)
                    put("f", if (m.hasCarrierFrequencyHz()) m.carrierFrequencyHz.toDouble() / 1e6 else 0.0)
                    put("code", if (Build.VERSION.SDK_INT >= 29 && m.hasCodeType()) m.codeType else "")
                    put("cn0", if (m.cn0DbHz.isFinite()) m.cn0DbHz else 0.0)
                })
            }
            lastMeas = arr
            lastMeasMs = System.currentTimeMillis()
        }
    }

    @SuppressLint("MissingPermission")
    private fun startGnss() {
        if (gnssStarted) return
        gnssStarted = true
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener, Looper.getMainLooper())
        lm.registerGnssStatusCallback(gnssCallback, main)
        try {
            if (!lm.registerGnssNavigationMessageCallback(navCallback, main)) navSupported = false
        } catch (e: Exception) {
            navSupported = false
        }
        try { lm.registerGnssMeasurementsCallback(measCallback, main) } catch (e: Exception) { }
        lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { lastLoc = it }
        push()
    }

    private fun finite(v: Float) = if (v.isFinite()) v.toDouble() else 0.0

    /** Sends the latest fix, satellite list and decoded ephemerides to the page. */
    private fun push() {
        if (!pageReady) return
        val sats = JSONArray()
        lastStatus?.let { s ->
            for (i in 0 until s.satelliteCount) {
                sats.put(JSONObject().apply {
                    put("c", s.getConstellationType(i))
                    put("id", s.getSvid(i))
                    put("az", finite(s.getAzimuthDegrees(i)))
                    put("el", finite(s.getElevationDegrees(i)))
                    put("cn0", finite(s.getCn0DbHz(i)))
                    put("used", s.usedInFix(i))
                    put("f", if (s.hasCarrierFrequencyHz(i)) finite(s.getCarrierFrequencyHz(i)) / 1e6 else 0.0)
                })
            }
        }
        val payload = JSONObject()
            .put("sats", sats)
            .put("now", System.currentTimeMillis())
            .put("meas", if (System.currentTimeMillis() - lastMeasMs < 3000) lastMeas else JSONArray())
            .put("nav", JSONObject()
                .put("supported", navSupported ?: JSONObject.NULL)
                .put("msgs", navMessages)
                .put("types", JSONArray(navTypesSeen.toList()))
                .put("ok", lnavGps.subframesOk + lnavQzss.subframesOk + galInav.pagesOk + bdsD1.subframesOk + glo.stringsOk)
                .put("bad", lnavGps.subframesBad + lnavQzss.subframesBad + galInav.pagesBad + bdsD1.subframesBad + glo.stringsBad)
                .put("by", JSONObject()
                    .put("GPS", JSONArray(listOf(lnavGps.subframesOk, lnavGps.subframesBad)))
                    .put("QZSS", JSONArray(listOf(lnavQzss.subframesOk, lnavQzss.subframesBad)))
                    .put("Galileo", JSONArray(listOf(galInav.pagesOk, galInav.pagesBad)))
                    .put("GLONASS", JSONArray(listOf(glo.stringsOk, glo.stringsBad)))
                    .put("BeiDou", JSONArray(listOf(bdsD1.subframesOk, bdsD1.subframesBad))))
                .put("geoD2", bdsD2Seen)
                .put("gloLayout", glo.layout)
                .put("gloRaw", JSONArray(glo.rejectedSamples)))
        lastLoc?.let { loc ->
            payload.put("lat", loc.latitude)
                .put("lon", loc.longitude)
                .put("alt", if (loc.hasAltitude()) loc.altitude else 0.0)
                .put("acc", if (loc.hasAccuracy()) loc.accuracy.toDouble() else -1.0)
                .put("utc", loc.time)
                .put("spd", if (loc.hasSpeed()) loc.speed.toDouble() else -1.0)        // m/s
                .put("brg", if (loc.hasBearing()) loc.bearing.toDouble() else -1.0)    // degrees true
            // getAltitude() is height above the WGS-84 ellipsoid; Android 14+ can also give MSL.
            if (Build.VERSION.SDK_INT >= 34 && loc.hasMslAltitude()) payload.put("msl", loc.mslAltitudeMeters)
        }
        web.evaluateJavascript("window.updateGnss && window.updateGnss($payload)", null)
    }

    private fun showMessage(text: String) {
        if (!pageReady) return
        web.evaluateJavascript(
            "window.showMessage && window.showMessage(${JSONObject.quote(text)})", null)
    }

    override fun onDestroy() {
        if (gnssStarted) {
            lm.removeUpdates(locListener)
            lm.unregisterGnssStatusCallback(gnssCallback)
            lm.unregisterGnssNavigationMessageCallback(navCallback)
            lm.unregisterGnssMeasurementsCallback(measCallback)
        }
        main.removeCallbacks(periodic)
        io.shutdown()
        web.destroy()
        super.onDestroy()
    }
}
