// GNSS helpers: GPS time, broadcast-ephemeris orbit propagation (IS-GPS-200),
// signal band naming, and grouping of per-signal status into per-satellite records.
(function (root) {
  const MU_GPS = 3.986005e14;       // GM used by GPS / QZSS broadcast orbits (m^3/s^2)
  const MU_GAL = 3.986004418e14;    // GM used by Galileo
  const OMEGA_E = 7.2921151467e-5;  // Earth rotation rate (rad/s)
  const GPS_EPOCH_UNIX = 315964800; // 1980-01-06T00:00:00Z
  const LEAP_SECONDS = 18;          // GPS - UTC
  const WEEK = 604800;
  const muOf = (sys) => (sys === 6 ? MU_GAL : MU_GPS);

  // Absolute GPS time: seconds since the GPS epoch (Galileo time uses the same scale).
  function gpsAbs(utcMs) { return utcMs / 1000 - GPS_EPOCH_UNIX + LEAP_SECONDS; }
  function gpsSecondsOfWeek(utcMs) { const t = gpsAbs(utcMs); return ((t % WEEK) + WEEK) % WEEK; }
  const sow = (tAbs) => ((tAbs % WEEK) + WEEK) % WEEK;

  function kepler(M, e) {
    let E = M;
    for (let k = 0; k < 12; k++) {
      const dE = (E - e * Math.sin(E) - M) / (1 - e * Math.cos(E));
      E -= dE;
      if (Math.abs(dE) < 1e-13) break;
    }
    return E;
  }

  // Broadcast ephemeris (GPS/QZSS LNAV, Galileo I/NAV) -> ECEF metres at absolute GPS time t.
  // e.toe is absolute; the node term uses toe's seconds-of-week because Omega0 is referenced
  // to the start of the GPS week (IS-GPS-200 Table 20-IV; same for Galileo).
  function ephToEcef(e, t) {
    const A = e.sqrtA * e.sqrtA;
    const n = Math.sqrt(muOf(e.sys) / (A * A * A)) + e.dn;
    const tk = t - e.toe;
    const E = kepler(e.M0 + n * tk, e.e);
    const v = Math.atan2(Math.sqrt(1 - e.e * e.e) * Math.sin(E), Math.cos(E) - e.e);
    const phi = v + e.omega;
    const s2 = Math.sin(2 * phi), c2 = Math.cos(2 * phi);
    const u = phi + e.Cus * s2 + e.Cuc * c2;
    const r = A * (1 - e.e * Math.cos(E)) + e.Crs * s2 + e.Crc * c2;
    const i = e.i0 + e.Cis * s2 + e.Cic * c2 + e.IDOT * tk;
    const xp = r * Math.cos(u), yp = r * Math.sin(u);
    const W = e.Omega0 + (e.OmegaDot - OMEGA_E) * tk - OMEGA_E * sow(e.toe);
    const cW = Math.cos(W), sW = Math.sin(W), ci = Math.cos(i), si = Math.sin(i);
    return { x: xp * cW - yp * ci * sW, y: xp * sW + yp * ci * cW, z: yp * si, tk };
  }
  // Broadcast ephemeris is fitted for ~4 h; for drawing it is used up to 4 h from toe.
  function ephValid(e, t) { return Math.abs(t - e.toe) < 4 * 3600; }

  // Almanac: the same Kepler orbit without harmonic corrections, delta-n or IDOT.
  function almToEcef(a, t) {
    const A = a.sqrtA * a.sqrtA;
    const n = Math.sqrt(muOf(a.sys) / (A * A * A));
    const tk = t - a.toa;
    const E = kepler(a.M0 + n * tk, a.e);
    const v = Math.atan2(Math.sqrt(1 - a.e * a.e) * Math.sin(E), Math.cos(E) - a.e);
    const u = v + a.omega, r = A * (1 - a.e * Math.cos(E));
    const xp = r * Math.cos(u), yp = r * Math.sin(u);
    const W = a.Omega0 + (a.OmegaDot - OMEGA_E) * tk - OMEGA_E * sow(a.toa);
    const cW = Math.cos(W), sW = Math.sin(W), ci = Math.cos(a.i), si = Math.sin(a.i);
    return { x: xp * cW - yp * ci * sW, y: xp * sW + yp * ci * cW, z: yp * si, tk };
  }
  function almValid(a, t) { return Math.abs(t - a.toa) < 14 * 86400; }
  function keplerPeriod(sqrtA, sys) { const A = sqrtA * sqrtA; return 2 * Math.PI * Math.sqrt(A * A * A / muOf(sys)); }

  // CelesTrak elements via SGP4 (satellite.js). Output: ECEF metres. TEME -> ECEF uses GMST only
  // (polar motion and the small TEME/PEF differences are far below what the globe can show).
  function gpEcef(rec, date, gmstFrozen) {
    if (typeof satellite === 'undefined' || !rec.satrec) return null;
    const pv = satellite.propagate(rec.satrec, date);
    if (!pv || !pv.position || isNaN(pv.position.x)) return null;
    const f = satellite.eciToEcf(pv.position, gmstFrozen !== undefined ? gmstFrozen : satellite.gstime(date));
    return { x: f.x * 1000, y: f.y * 1000, z: f.z * 1000 };
  }
  function gpPeriodSec(rec) { return rec.satrec && rec.satrec.no ? (2 * Math.PI / rec.satrec.no) * 60 : 43080; }

  // Signal name from constellation, carrier frequency and (when known) the raw code type.
  // Android code types: GPS/QZSS L1 C/A = "C", L1C = "L"/"S"/"X", QZSS L1S = "Z";
  // Galileo E1 = "B"/"C"/"X"; BeiDou B1I = "I", B1C = "D"/"P"/"X".
  const near = (f, x) => Math.abs(f - x) < 1.5;
  function signalName(c, fMHz, code) {
    code = code || '';
    if (!fMHz) fMHz = 1575.42;
    if (c === 3) return fMHz > 1240 && fMHz < 1250 ? 'G2' : 'G1';
    if (near(fMHz, 1575.42)) {
      if (c === 6) return 'E1';
      if (c === 5) return 'B1C';
      if (c === 2) return 'L1';
      if (code === 'C') return 'L1 C/A';
      if (code === 'Z') return 'L1S';
      if ('LSX'.includes(code) && code) return 'L1C';
      return 'L1';
    }
    if (near(fMHz, 1561.098)) return 'B1I';
    if (near(fMHz, 1176.45)) return c === 6 ? 'E5a' : (c === 5 ? 'B2a' : 'L5');
    if (near(fMHz, 1207.14)) return c === 6 ? 'E5b' : 'B2I';
    if (near(fMHz, 1227.60)) return 'L2';
    if (near(fMHz, 1278.75)) return 'E6';
    if (near(fMHz, 1268.52)) return 'B3I';
    return fMHz.toFixed(0);
  }
  const bandOf = (c, f) => signalName(c, f, '');
  const LOW_BANDS = new Set(['L5', 'E5a', 'B2a', 'E5b', 'B2I', 'L2', 'G2', 'E6', 'B3I']);
  const ORDER = ['L1 C/A', 'L1C', 'L1S', 'L1', 'E1', 'B1I', 'B1C', 'G1', 'L2', 'G2', 'E6', 'B3I', 'E5b', 'B2I', 'L5', 'E5a', 'B2a'];
  const rank = (n) => { const i = ORDER.indexOf(n); return i < 0 ? 99 : i; };

  // GnssStatus gives one entry per signal (direction, strength, used-in-fix) but no code type;
  // raw measurements give the code type. Merge both into one record per satellite, matching each
  // measurement to the status entry on the same frequency with the closest signal strength.
  function groupSats(raw, meas) {
    const map = new Map();
    for (const s of raw) {
      const key = s.c + ':' + s.id;
      let g = map.get(key);
      if (!g) { g = { c: s.c, id: s.id, az: s.az, el: s.el, used: false, cn0: 0, sig: [], bands: [] }; map.set(key, g); }
      if (s.el !== 0 || s.az !== 0) { g.az = s.az; g.el = s.el; }
      g.used = g.used || s.used;
      g.cn0 = Math.max(g.cn0, s.cn0);
      g.sig.push(s);
    }
    const measBySat = new Map();
    for (const m of meas || []) {
      const key = m.c + ':' + m.id;
      if (!measBySat.has(key)) measBySat.set(key, []);
      measBySat.get(key).push(m);
    }
    for (const [key, g] of map) {
      const ms = measBySat.get(key);
      if (ms && ms.length) {
        const pool = g.sig.slice();
        for (const m of ms) {
          let best = -1, bestD = Infinity;
          pool.forEach((s, i) => {
            const fs = s.f || 1575.42, fm = m.f || 1575.42;
            if (Math.abs(fs - fm) > 0.5) return;
            const d = Math.abs(s.cn0 - m.cn0);
            if (d < bestD) { bestD = d; best = i; }
          });
          const st = best >= 0 ? pool.splice(best, 1)[0] : null;
          g.bands.push({ band: signalName(g.c, m.f, m.code), cn0: st ? st.cn0 : m.cn0, used: st ? st.used : g.used });
        }
        for (const s of pool) g.bands.push({ band: signalName(g.c, s.f, ''), cn0: s.cn0, used: s.used });
      } else {
        for (const s of g.sig) g.bands.push({ band: signalName(g.c, s.f, ''), cn0: s.cn0, used: s.used });
      }
      g.bands.sort((a, b) => rank(a.band) - rank(b.band));
      // Same name twice without code info (e.g. two unlabelled L1 signals): number them.
      const seen = {};
      for (const b of g.bands) { seen[b.band] = (seen[b.band] || 0) + 1; if (seen[b.band] > 1) b.band += ' #' + seen[b.band]; }
      g.multi = g.bands.length > 1;
      g.dual = g.bands.some(b => LOW_BANDS.has(b.band)) && g.bands.some(b => !LOW_BANDS.has(b.band));
      delete g.sig;
    }
    return [...map.values()];
  }

  const api = { OMEGA_E, gpsAbs, gpsSecondsOfWeek, ephToEcef, ephValid, almToEcef, almValid, keplerPeriod, gpEcef, gpPeriodSec, bandOf, signalName, groupSats, LOW_BANDS };
  if (typeof module !== 'undefined') module.exports = api; else root.GNSS = api;
})(this);
