// GNSS helpers: GPS time, broadcast-ephemeris orbit propagation (IS-GPS-200),
// signal band naming, and grouping of per-signal status into per-satellite records.
(function (root) {
  const MU_GPS = 3.986005e14;       // GM used by GPS / QZSS broadcast orbits (m^3/s^2)
  const MU_GAL = 3.986004418e14;    // GM used by Galileo and BeiDou
  const OMEGA_E = 7.2921151467e-5;  // Earth rotation rate (rad/s), GPS / Galileo
  const OMEGA_BDS = 7.2921150e-5;   // Earth rotation rate used by BeiDou (CGCS2000)
  const GPS_EPOCH_UNIX = 315964800; // 1980-01-06T00:00:00Z
  const LEAP_SECONDS = 18;          // GPS - UTC
  const WEEK = 604800;
  const muOf = (sys) => (sys === 6 || sys === 5 ? MU_GAL : MU_GPS);
  const omegaOf = (sys) => (sys === 5 ? OMEGA_BDS : OMEGA_E);
  // BeiDou GEO satellites (C01-C05, C59-C63) use a different final rotation (BDS-SIS-ICD 5.2.4.12).
  const bdsGeo = (e) => e.sys === 5 && (e.svid <= 5 || (e.svid >= 59 && e.svid <= 63));

  // Absolute GPS time: seconds since the GPS epoch (Galileo time uses the same scale).
  function gpsAbs(utcMs) { return utcMs / 1000 - GPS_EPOCH_UNIX + LEAP_SECONDS; }
  function gpsSecondsOfWeek(utcMs) { const t = gpsAbs(utcMs); return ((t % WEEK) + WEEK) % WEEK; }
  const sow = (tAbs) => ((tAbs % WEEK) + WEEK) % WEEK;

  function kepler(M, e) {
    let E = M;
    for (let k = 0; k < 12; k++) {
      const dE = (E - e * Math.sin(E) - M) / (1 - e * Math.cos(E));
      E -= dE;
      if (Math.abs(dE) < 1e-13) break;
    }
    return E;
  }

  // Broadcast ephemeris (GPS/QZSS LNAV, Galileo I/NAV, BeiDou D1) -> ECEF metres at absolute GPS
  // time t. e.toe is absolute; the node term uses toe's seconds of the system's own week because
  // Omega0 is referenced to the week start (IS-GPS-200 Table 20-IV; same for Galileo and BeiDou,
  // whose weeks start 14 s later, so e.toeSow is sent for it). GLONASS goes to gloToEcef.
  function ephToEcef(e, t) {
    if (e.sys === 3) return gloToEcef(e, t);
    const A = e.sqrtA * e.sqrtA;
    const n = Math.sqrt(muOf(e.sys) / (A * A * A)) + e.dn;
    const tk = t - e.toe;
    const E = kepler(e.M0 + n * tk, e.e);
    const v = Math.atan2(Math.sqrt(1 - e.e * e.e) * Math.sin(E), Math.cos(E) - e.e);
    const phi = v + e.omega;
    const s2 = Math.sin(2 * phi), c2 = Math.cos(2 * phi);
    const u = phi + e.Cus * s2 + e.Cuc * c2;
    const r = A * (1 - e.e * Math.cos(E)) + e.Crs * s2 + e.Crc * c2;
    const i = e.i0 + e.Cis * s2 + e.Cic * c2 + e.IDOT * tk;
    const xp = r * Math.cos(u), yp = r * Math.sin(u);
    const wE = omegaOf(e.sys), toeSow = e.toeSow !== undefined ? e.toeSow : sow(e.toe);
    const ci = Math.cos(i), si = Math.sin(i);
    if (bdsGeo(e)) {
      // GEO: node in the inertial frame, then rotate by -5 deg about X and by wE*tk about Z.
      const W = e.Omega0 + e.OmegaDot * tk - wE * toeSow;
      const cW = Math.cos(W), sW = Math.sin(W);
      const X = xp * cW - yp * ci * sW, Y = xp * sW + yp * ci * cW, Z = yp * si;
      const f = -5 * Math.PI / 180, cf = Math.cos(f), sf = Math.sin(f);
      const y1 = Y * cf + Z * sf, z1 = -Y * sf + Z * cf;
      const a = wE * tk, ca = Math.cos(a), sa = Math.sin(a);
      return { x: X * ca + y1 * sa, y: -X * sa + y1 * ca, z: z1, tk };
    }
    const W = e.Omega0 + (e.OmegaDot - wE) * tk - wE * toeSow;
    const cW = Math.cos(W), sW = Math.sin(W);
    return { x: xp * cW - yp * ci * sW, y: xp * sW + yp * ci * cW, z: yp * si, tk };
  }
  // Kepler broadcast ephemeris is fitted for ~4 h; for drawing it is used up to 4 h from toe.
  // GLONASS states are integrated, good to the km level for ~2 h either side of tb.
  function ephValid(e, t) { return Math.abs(t - e.toe) < (e.sys === 3 ? 2 : 4) * 3600; }
  function ephPeriod(e) { return e.sys === 3 ? 40544 : keplerPeriod(e.sqrtA, e.sys); }

  // GLONASS: integrate the PZ-90 state from tb with 4th-order Runge-Kutta (GLONASS ICD A.3.1.2):
  // central gravity + J2 + rotating-frame terms + the broadcast luni-solar acceleration.
  const MU_GLO = 3.9860044e14, J2_GLO = 1.0826257e-3, RE_GLO = 6378136, OMEGA_GLO = 7.292115e-5;
  function gloDeriv(s, acc) {
    const [x, y, z, vx, vy, vz] = s;
    const r2 = x * x + y * y + z * z, r = Math.sqrt(r2), r3 = r2 * r;
    const a = 1.5 * J2_GLO * MU_GLO * RE_GLO * RE_GLO / (r2 * r3);
    const b = 5 * z * z / r2, c = -MU_GLO / r3 - a * (1 - b), w2 = OMEGA_GLO * OMEGA_GLO;
    return [vx, vy, vz,
      (c + w2) * x + 2 * OMEGA_GLO * vy + acc[0],
      (c + w2) * y - 2 * OMEGA_GLO * vx + acc[1],
      (c - 2 * a) * z + acc[2]];
  }
  function gloStep(s, h, acc) {
    const add = (u, k, f) => u.map((v, i) => v + k[i] * f);
    const k1 = gloDeriv(s, acc), k2 = gloDeriv(add(s, k1, h / 2), acc);
    const k3 = gloDeriv(add(s, k2, h / 2), acc), k4 = gloDeriv(add(s, k3, h), acc);
    return s.map((v, i) => v + (h / 6) * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]));
  }
  // The trajectory is integrated once per ephemeris (60 s steps, +-8 h) and cached; positions in
  // between come from cubic Hermite interpolation using the velocities.
  const GLO_STEP = 60, GLO_SPAN = 8 * 3600;
  function gloTrajectory(g) {
    if (g._traj) return g._traj;
    const acc = [g.ax, g.ay, g.az], n = GLO_SPAN / GLO_STEP, s0 = [g.x, g.y, g.z, g.vx, g.vy, g.vz];
    const fwd = [s0], back = [s0];
    for (let k = 0; k < n; k++) fwd.push(gloStep(fwd[k], GLO_STEP, acc));
    for (let k = 0; k < n; k++) back.push(gloStep(back[k], -GLO_STEP, acc));
    g._traj = back.slice(1).reverse().concat(fwd);   // index n = tb
    return g._traj;
  }
  function gloToEcef(g, t) {
    const tr = gloTrajectory(g), n = GLO_SPAN / GLO_STEP;
    const u = (t - g.toe) / GLO_STEP + n;
    const k = Math.max(0, Math.min(tr.length - 2, Math.floor(u))), f = u - k, h = GLO_STEP;
    const p = tr[k], q = tr[k + 1];
    const h00 = 2 * f ** 3 - 3 * f ** 2 + 1, h10 = f ** 3 - 2 * f ** 2 + f, h01 = -2 * f ** 3 + 3 * f ** 2, h11 = f ** 3 - f ** 2;
    const c = (i) => h00 * p[i] + h10 * h * p[i + 3] + h01 * q[i] + h11 * h * q[i + 3];
    return { x: c(0), y: c(1), z: c(2), tk: t - g.toe };
  }

  // Almanac: the same Kepler orbit without harmonic corrections, delta-n or IDOT.
  function almToEcef(a, t) {
    const A = a.sqrtA * a.sqrtA;
    const n = Math.sqrt(muOf(a.sys) / (A * A * A));
    const tk = t - a.toa;
    const E = kepler(a.M0 + n * tk, a.e);
    const v = Math.atan2(Math.sqrt(1 - a.e * a.e) * Math.sin(E), Math.cos(E) - a.e);
    const u = v + a.omega, r = A * (1 - a.e * Math.cos(E));
    const xp = r * Math.cos(u), yp = r * Math.sin(u);
    const W = a.Omega0 + (a.OmegaDot - OMEGA_E) * tk - OMEGA_E * sow(a.toa);
    const cW = Math.cos(W), sW = Math.sin(W), ci = Math.cos(a.i), si = Math.sin(a.i);
    return { x: xp * cW - yp * ci * sW, y: xp * sW + yp * ci * cW, z: yp * si, tk };
  }
  function almValid(a, t) { return Math.abs(t - a.toa) < 14 * 86400; }
  function keplerPeriod(sqrtA, sys) { const A = sqrtA * sqrtA; return 2 * Math.PI * Math.sqrt(A * A * A / muOf(sys)); }

  // CelesTrak elements via SGP4 (satellite.js). Output: ECEF metres. TEME -> ECEF uses GMST only
  // (polar motion and the small TEME/PEF differences are far below what the globe can show).
  function gpEcef(rec, date, gmstFrozen) {
    if (typeof satellite === 'undefined' || !rec.satrec) return null;
    const pv = satellite.propagate(rec.satrec, date);
    if (!pv || !pv.position || isNaN(pv.position.x)) return null;
    const f = satellite.eciToEcf(pv.position, gmstFrozen !== undefined ? gmstFrozen : satellite.gstime(date));
    return { x: f.x * 1000, y: f.y * 1000, z: f.z * 1000 };
  }
  function gpPeriodSec(rec) { return rec.satrec && rec.satrec.no ? (2 * Math.PI / rec.satrec.no) * 60 : 43080; }

  // Signal name from constellation, carrier frequency and (when known) the raw code type.
  // Android code types: GPS/QZSS L1 C/A = "C", L1C = "L"/"S"/"X", QZSS L1S = "Z";
  // Galileo E1 = "B"/"C"/"X"; BeiDou B1I = "I", B1C = "D"/"P"/"X".
  const near = (f, x) => Math.abs(f - x) < 1.5;
  function signalName(c, fMHz, code) {
    code = code || '';
    if (!fMHz) fMHz = 1575.42;
    if (c === 3) return fMHz > 1240 && fMHz < 1250 ? 'G2' : 'G1';
    if (near(fMHz, 1575.42)) {
      if (c === 6) return 'E1';
      if (c === 5) return 'B1C';
      if (c === 2) return 'L1';
      if (code === 'C') return 'L1 C/A';
      if (code === 'Z') return 'L1S';
      if ('LSX'.includes(code) && code) return 'L1C';
      return 'L1';
    }
    if (near(fMHz, 1561.098)) return 'B1I';
    if (near(fMHz, 1176.45)) return c === 6 ? 'E5a' : (c === 5 ? 'B2a' : 'L5');
    if (near(fMHz, 1207.14)) return c === 6 ? 'E5b' : 'B2I';
    if (near(fMHz, 1227.60)) return 'L2';
    if (near(fMHz, 1278.75)) return 'E6';
    if (near(fMHz, 1268.52)) return 'B3I';
    return fMHz.toFixed(0);
  }
  const bandOf = (c, f) => signalName(c, f, '');
  const LOW_BANDS = new Set(['L5', 'E5a', 'B2a', 'E5b', 'B2I', 'L2', 'G2', 'E6', 'B3I']);
  const ORDER = ['L1 C/A', 'L1C', 'L1S', 'L1', 'E1', 'B1I', 'B1C', 'G1', 'L2', 'G2', 'E6', 'B3I', 'E5b', 'B2I', 'L5', 'E5a', 'B2a'];
  const rank = (n) => { const i = ORDER.indexOf(n); return i < 0 ? 99 : i; };

  // GnssStatus gives one entry per signal (direction, strength, used-in-fix) but no code type;
  // raw measurements give the code type. Merge both into one record per satellite, matching each
  // measurement to the status entry on the same frequency with the closest signal strength.
  function groupSats(raw, meas) {
    const map = new Map();
    for (const s of raw) {
      const key = s.c + ':' + s.id;
      let g = map.get(key);
      if (!g) { g = { c: s.c, id: s.id, az: s.az, el: s.el, used: false, cn0: 0, sig: [], bands: [] }; map.set(key, g); }
      if (s.el !== 0 || s.az !== 0) { g.az = s.az; g.el = s.el; }
      g.used = g.used || s.used;
      g.cn0 = Math.max(g.cn0, s.cn0);
      g.sig.push(s);
    }
    const measBySat = new Map();
    for (const m of meas || []) {
      const key = m.c + ':' + m.id;
      if (!measBySat.has(key)) measBySat.set(key, []);
      measBySat.get(key).push(m);
    }
    for (const [key, g] of map) {
      const ms = measBySat.get(key);
      if (ms && ms.length) {
        const pool = g.sig.slice();
        for (const m of ms) {
          let best = -1, bestD = Infinity;
          pool.forEach((s, i) => {
            const fs = s.f || 1575.42, fm = m.f || 1575.42;
            if (Math.abs(fs - fm) > 0.5) return;
            const d = Math.abs(s.cn0 - m.cn0);
            if (d < bestD) { bestD = d; best = i; }
          });
          const st = best >= 0 ? pool.splice(best, 1)[0] : null;
          g.bands.push({ band: signalName(g.c, m.f, m.code), cn0: st ? st.cn0 : m.cn0, used: st ? st.used : g.used });
        }
        for (const s of pool) g.bands.push({ band: signalName(g.c, s.f, ''), cn0: s.cn0, used: s.used });
      } else {
        for (const s of g.sig) g.bands.push({ band: signalName(g.c, s.f, ''), cn0: s.cn0, used: s.used });
      }
      g.bands.sort((a, b) => rank(a.band) - rank(b.band));
      // Same name twice without code info (e.g. two unlabelled L1 signals): number them.
      const seen = {};
      for (const b of g.bands) { seen[b.band] = (seen[b.band] || 0) + 1; if (seen[b.band] > 1) b.band += ' #' + seen[b.band]; }
      g.multi = g.bands.length > 1;
      g.dual = g.bands.some(b => LOW_BANDS.has(b.band)) && g.bands.some(b => !LOW_BANDS.has(b.band));
      delete g.sig;
    }
    return [...map.values()];
  }

  const api = { OMEGA_E, gpsAbs, gpsSecondsOfWeek, ephToEcef, ephValid, ephPeriod, gloToEcef, almToEcef, almValid, keplerPeriod, gpEcef, gpPeriodSec, bandOf, signalName, groupSats, LOW_BANDS };
  if (typeof module !== 'undefined') module.exports = api; else root.GNSS = api;
})(this);
