// GNSS helpers: GPS time, broadcast-ephemeris orbit propagation (IS-GPS-200),
// signal band naming, and grouping of per-signal status into per-satellite records.
(function (root) {
  const MU = 3.986005e14;          // WGS-84 GM used by GPS (m^3/s^2)
  const OMEGA_E = 7.2921151467e-5; // Earth rotation rate (rad/s)
  const GPS_EPOCH_UNIX = 315964800; // 1980-01-06T00:00:00Z
  const LEAP_SECONDS = 18;         // GPS - UTC
  const WEEK = 604800;

  function gpsSecondsOfWeek(utcMs) {
    const t = utcMs / 1000 - GPS_EPOCH_UNIX + LEAP_SECONDS;
    return ((t % WEEK) + WEEK) % WEEK;
  }

  function wrapWeek(dt) {
    if (dt > WEEK / 2) return dt - WEEK;
    if (dt < -WEEK / 2) return dt + WEEK;
    return dt;
  }

  // Earth-fixed (WGS-84 ECEF) satellite position in metres at GPS seconds-of-week t.
  function ephToEcef(e, t) {
    const A = e.sqrtA * e.sqrtA;
    const n = Math.sqrt(MU / (A * A * A)) + e.dn;
    const tk = wrapWeek(t - e.toe);
    const M = e.M0 + n * tk;
    let E = M;
    for (let k = 0; k < 12; k++) {
      const dE = (E - e.e * Math.sin(E) - M) / (1 - e.e * Math.cos(E));
      E -= dE;
      if (Math.abs(dE) < 1e-13) break;
    }
    const v = Math.atan2(Math.sqrt(1 - e.e * e.e) * Math.sin(E), Math.cos(E) - e.e);
    const phi = v + e.omega;
    const s2 = Math.sin(2 * phi), c2 = Math.cos(2 * phi);
    const u = phi + e.Cus * s2 + e.Cuc * c2;
    const r = A * (1 - e.e * Math.cos(E)) + e.Crs * s2 + e.Crc * c2;
    const i = e.i0 + e.Cis * s2 + e.Cic * c2 + e.IDOT * tk;
    const xp = r * Math.cos(u), yp = r * Math.sin(u);
    const W = e.Omega0 + (e.OmegaDot - OMEGA_E) * tk - OMEGA_E * e.toe;
    const cW = Math.cos(W), sW = Math.sin(W), ci = Math.cos(i), si = Math.sin(i);
    return { x: xp * cW - yp * ci * sW, y: xp * sW + yp * ci * cW, z: yp * si, tk };
  }

  // Broadcast ephemeris is good to a few metres near toe; for drawing we allow +/-4 h.
  function ephValid(e, t) { return Math.abs(wrapWeek(t - e.toe)) < 4 * 3600; }

  function bandOf(c, fMHz) {
    if (!fMHz) return c === 3 ? 'G1' : (c === 6 ? 'E1' : (c === 5 ? 'B1' : 'L1'));
    const near = (x) => Math.abs(fMHz - x) < 1.5;
    if (near(1575.42)) return c === 6 ? 'E1' : (c === 5 ? 'B1C' : 'L1');
    if (near(1176.45)) return c === 6 ? 'E5a' : (c === 5 ? 'B2a' : 'L5');
    if (near(1207.14)) return c === 6 ? 'E5b' : 'B2I';
    if (near(1227.60)) return 'L2';
    if (near(1561.098)) return 'B1I';
    if (near(1278.75)) return 'E6';
    if (near(1268.52)) return 'B3I';
    if (fMHz > 1597 && fMHz < 1607) return 'G1';
    if (fMHz > 1240 && fMHz < 1250) return 'G2';
    return fMHz.toFixed(0);
  }
  const LOW_BANDS = new Set(['L5', 'E5a', 'B2a', 'E5b', 'B2I', 'L2', 'G2', 'E6', 'B3I']);

  // The receiver reports one entry per signal; merge them into one record per satellite.
  function groupSats(raw) {
    const map = new Map();
    for (const s of raw) {
      const key = s.c + ':' + s.id;
      let g = map.get(key);
      if (!g) {
        g = { c: s.c, id: s.id, az: s.az, el: s.el, used: false, cn0: 0, bands: [] };
        map.set(key, g);
      }
      if (s.el !== 0 || s.az !== 0) { g.az = s.az; g.el = s.el; }
      g.used = g.used || s.used;
      g.cn0 = Math.max(g.cn0, s.cn0);
      g.bands.push({ band: bandOf(s.c, s.f), cn0: s.cn0, used: s.used });
    }
    for (const g of map.values()) {
      g.bands.sort((a, b) => (LOW_BANDS.has(a.band) ? 1 : 0) - (LOW_BANDS.has(b.band) ? 1 : 0));
      g.dual = g.bands.some(b => LOW_BANDS.has(b.band)) && g.bands.some(b => !LOW_BANDS.has(b.band));
    }
    return [...map.values()];
  }

  const api = { gpsSecondsOfWeek, wrapWeek, ephToEcef, ephValid, bandOf, groupSats, LOW_BANDS };
  if (typeof module !== 'undefined') module.exports = api; else root.GNSS = api;
})(this);
