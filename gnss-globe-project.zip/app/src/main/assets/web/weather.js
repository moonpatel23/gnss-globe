// Weather and warnings on the 3D globe (online layers; the last copy of each data feed is kept on
// the tablet by the app's proxy, so warnings still show offline).
//
//   Clouds          NOAA GOES-East/West + JMA Himawari via NASA GIBS (time-aware, 10 min steps)
//   Radar           NEXRAD composite via Iowa Environmental Mesonet (5 min archive)
//   Forecast radar  NOAA HRRR simulated reflectivity via IEM (15 min steps, 18 h)
//   NWS warnings    api.weather.gov active alerts that carry a polygon
//   Naval warnings  NGA broadcast warnings (HYDROLANT/HYDROPAC/HYDROARC, NAVAREA IV/XII); the
//                   positions are read out of the message text; launch/debris areas highlighted
//   Hurricanes      NHC CurrentStorms.json: forecast cone and track (KMZ)
//   Day/night       Cesium sun lighting at the slider time
//
// Everything online goes through /proxy/<scheme>/<host>/<path> (WebProxy.kt), except GIBS which
// serves browser-friendly tiles directly.
(function () {
  'use strict';
  const PX = (u) => '/proxy/' + u.replace('://', '/');
  const MIN = 60e3, STEP = 10 * MIN, PAST_STEPS = 18, FUTURE_STEPS = 36;
  const WX = Object.assign({ radar: false, hrrr: false, nws: false, naval: false, tropics: false, daynight: false },
    loadJSON('wx', {}));
  const cloudsOn = () => settings.showClouds !== false && settings.clouds !== 'off';
  const save = () => saveJSON('wx', WX);
  const status = { clouds: '', radar: '', hrrr: '', nws: '', naval: '', tropics: '', daynight: '' };
  const hhmm = (ms) => new Date(ms).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const pad = (n, w = 2) => String(n).padStart(w, '0');
  const utcStamp = (ms) => { const d = new Date(ms);
    return `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}`; };

  // ---------- Time ----------
  let offset = 0;                 // slider steps of 10 min: 0 = live, < 0 past, > 0 future
  const baseTime = () => Math.floor(Date.now() / STEP) * STEP;
  const sliderTime = () => (offset === 0 ? Date.now() : baseTime() + offset * STEP);

  // ---------- Frame sets: one imagery layer set per time, kept for smooth looping ----------
  // A frame not on screen stays loaded at alpha 0, so stepping back to it is instant.
  class FrameSet {
    constructor(max) { this.frames = new Map(); this.max = max; this.current = null; this.errors = 0; }
    ensure(key, make) {
      let f = this.frames.get(key);
      if (!f) {
        f = { layers: make(this), used: 0 };
        for (const l of f.layers) l.alpha = 0;
        this.frames.set(key, f);
      }
      f.used = performance.now();
      return f;
    }
    show(key, make, alpha) {
      this.ensure(key, make);
      this.current = key;
      for (const [k, g] of this.frames) for (const l of g.layers) l.alpha = k === key ? alpha : 0;
      this.evict();
    }
    hide() { this.current = null; for (const g of this.frames.values()) for (const l of g.layers) l.alpha = 0; }
    setAlpha(a) { const f = this.frames.get(this.current); if (f) for (const l of f.layers) l.alpha = a; }
    evict() {
      while (this.frames.size > this.max) {
        let oldK = null, oldT = Infinity;
        for (const [k, g] of this.frames) if (k !== this.current && g.used < oldT) { oldT = g.used; oldK = k; }
        if (oldK === null) break;
        for (const l of this.frames.get(oldK).layers) viewer.imageryLayers.remove(l, true);
        this.frames.delete(oldK);
      }
    }
    clear() {
      for (const g of this.frames.values()) for (const l of g.layers) viewer.imageryLayers.remove(l, true);
      this.frames.clear(); this.current = null; this.errors = 0;
    }
    layers() { const out = []; for (const g of this.frames.values()) out.push(...g.layers); return out; }
  }
  const cloudFrames = new FrameSet(16), radarFrames = new FrameSet(16), hrrrFrames = new FrameSet(16);
  // Radar on top of clouds, forecast radar on top of everything.
  function restack() {
    for (const l of radarFrames.layers()) viewer.imageryLayers.raiseToTop(l);
    for (const l of hrrrFrames.layers()) viewer.imageryLayers.raiseToTop(l);
  }

  // ---------- Clouds (NASA GIBS) ----------
  const GIBS_WMS = 'https://gibs.earthdata.nasa.gov/wms/epsg4326/best/wms.cgi';
  function gibsProvider(layer, set, timeIso, stamp) {
    const parameters = { format: 'image/png', transparent: true };
    if (timeIso) parameters.time = timeIso; else parameters._ = stamp;
    const p = new Cesium.WebMapServiceImageryProvider({
      url: GIBS_WMS, layers: layer, parameters,
      tilingScheme: new Cesium.GeographicTilingScheme(), maximumLevel: 6,
      credit: 'NOAA GOES / JMA Himawari imagery via NASA GIBS',
    });
    p.errorEvent.addEventListener(() => { set.errors++; });
    return p;
  }
  function makeClouds(timeIso, stamp) {
    return (set) => {
      const ir = settings.clouds === 'ir', out = [];
      const add = (name) => {
        const l = viewer.imageryLayers.addImageryProvider(gibsProvider(name, set, timeIso, stamp));
        if (ir) { l.colorToAlpha = C.BLACK; l.colorToAlphaThreshold = 0.32; l.brightness = 1.3; }
        out.push(l);
      };
      // Later layers sit on top where the disks overlap: GOES-East (centred on the Americas) wins.
      if (settings.cloudsWide) {
        if (ir) add('Himawari_AHI_Band13_Clean_Infrared');           // no GeoColor for Himawari in GIBS
        add(ir ? 'GOES-West_ABI_Band13_Clean_Infrared' : 'GOES-West_ABI_GeoColor');
      }
      add(ir ? 'GOES-East_ABI_Band13_Clean_Infrared' : 'GOES-East_ABI_GeoColor');
      return out;
    };
  }
  // GIBS has a GOES image every 10 min, posted ~20-40 min late: the last 30 min use "latest".
  function cloudKey(t) {
    if (offset >= -3) return { key: 'live' + Math.floor(Date.now() / STEP), iso: null, label: 'latest' };
    const iso = new Date(t).toISOString().slice(0, 16) + ':00Z';
    return { key: iso, iso, label: hhmm(t) };
  }
  function showClouds(t) {
    if (!cloudsOn()) { cloudFrames.clear(); status.clouds = 'off'; return; }
    if (!navigator.onLine) { status.clouds = 'needs internet'; }
    const k = cloudKey(t);
    cloudFrames.show(k.key, makeClouds(k.iso, k.key), settings.cloudAlpha);
    status.clouds = `${settings.clouds === 'ir' ? 'infrared' : 'GeoColor'} · ${k.label}` +
      (cloudFrames.errors > 12 ? ' · some tiles failed' : '');
  }

  // ---------- Radar (IEM NEXRAD composite) ----------
  const CONUS = Cesium.Rectangle.fromDegrees(-128, 20, -63, 53);
  function iemProvider(layerName, cachePath, set, credit) {
    const p = new Cesium.UrlTemplateImageryProvider({
      url: PX(`https://mesonet.agron.iastate.edu/${cachePath}/tile.py/1.0.0/${layerName}/`) + '{z}/{x}/{y}.png',
      tilingScheme: new Cesium.WebMercatorTilingScheme(), maximumLevel: 9, rectangle: CONUS, credit,
    });
    p.errorEvent.addEventListener(() => { set.errors++; });
    return p;
  }
  function showRadar(t) {
    if (!WX.radar) { radarFrames.clear(); status.radar = 'off'; return; }
    if (offset > 0) { radarFrames.hide(); status.radar = 'observed radar stops at now'; return; }
    let key, layer, path, label;
    if (offset === 0) {
      key = 'live' + Math.floor(Date.now() / (5 * MIN)); layer = 'ridge::USCOMP-N0Q-0'; path = 'cache'; label = 'latest';
    } else {
      key = utcStamp(t); layer = `ridge::USCOMP-N0Q-${key}`; path = 'c'; label = hhmm(t);
    }
    radarFrames.show(key, (set) => [viewer.imageryLayers.addImageryProvider(
      iemProvider(layer, path, set, 'NEXRAD via Iowa Environmental Mesonet'))], 0.8);
    status.radar = `U.S. NEXRAD · ${label}` + (radarFrames.errors > 12 ? ' · some tiles failed' : '');
  }

  // ---------- Forecast radar (HRRR via IEM) ----------
  let hrrrInit = null, hrrrFetched = 0, hrrrErr = '';
  async function refreshHrrrInit() {
    if (Date.now() - hrrrFetched < 20 * MIN && hrrrInit) return;
    try {
      const r = await fetch(PX('https://mesonet.agron.iastate.edu/data/gis/images/4326/hrrr/refd_1080.json'));
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const j = await r.json();
      const ms = Date.parse(j.model_init_utc);
      if (!isFinite(ms)) throw new Error('no model_init_utc');
      hrrrInit = ms; hrrrFetched = Date.now();
      hrrrErr = '';
    } catch (e) { hrrrErr = 'model run time unavailable: ' + e.message; }
  }
  function showHrrr(t) {
    if (!WX.hrrr) { hrrrFrames.clear(); status.hrrr = 'off'; return; }
    if (offset <= 0) { hrrrFrames.hide(); status.hrrr = 'move the slider forward to see the forecast'; return; }
    if (!hrrrInit) { hrrrFrames.hide(); status.hrrr = hrrrErr || 'loading model run…'; return; }
    const F = Math.round((t - hrrrInit) / (15 * MIN)) * 15;
    if (F < 0 || F > 1080) { hrrrFrames.hide(); status.hrrr = 'beyond the 18 h forecast'; return; }
    const init = utcStamp(hrrrInit), key = `${init}F${F}`;
    hrrrFrames.show(key, (set) => [viewer.imageryLayers.addImageryProvider(
      iemProvider(`hrrr::REFD-F${pad(F, 4)}-${init}`, 'c', set, 'NOAA HRRR via Iowa Environmental Mesonet'))], 0.75);
    status.hrrr = `HRRR ${pad(new Date(hrrrInit).getUTCHours())}Z run · +${Math.floor(F / 60)}:${pad(F % 60)} → ${hhmm(t)}` +
      (hrrrFrames.errors > 12 ? ' · some tiles failed' : '');
  }

  // ---------- Day/night ----------
  function showLighting(t) {
    viewer.scene.globe.enableLighting = !!WX.daynight;
    viewer.clock.shouldAnimate = false;
    viewer.clock.currentTime = Cesium.JulianDate.fromDate(new Date(WX.daynight ? t : Date.now()));
    status.daynight = WX.daynight ? `sunlight at ${hhmm(t)}` : 'off';
  }

  function applyTime() {
    const t = sliderTime();
    showClouds(t); showRadar(t); showHrrr(t); showLighting(t);
    restack();
    try { cloudStatus = status.clouds; } catch (e) { /* settings page hook */ }
    updateBar(); updatePanel();
    viewer.scene.requestRender();
  }

  // ---------- Vector feeds (NWS, NGA, NHC) ----------
  async function fetchFeed(url, as = 'json') {
    const r = await fetch(PX(url));
    if (!r.ok) throw new Error('HTTP ' + r.status + (r.status === 502 ? ' (offline or server unreachable)' : ''));
    const cached = r.headers.get('X-Proxy-Cache');
    const data = as === 'json' ? await r.json() : await r.text();
    return { data, cachedAt: cached ? Number(cached) : null };
  }
  const when = (cachedAt) => cachedAt ? `offline copy from ${hhmm(cachedAt)}` : `updated ${hhmm(Date.now())}`;
  const sources = {};   // name -> CustomDataSource
  function source(name) {
    if (!sources[name]) { sources[name] = new Cesium.CustomDataSource(name); viewer.dataSources.add(sources[name]); }
    return sources[name];
  }
  function dropSource(name) {
    if (sources[name]) { viewer.dataSources.remove(sources[name], true); delete sources[name]; }
  }
  // Area outlines: translucent fill on the ground + a solid outline slightly above it.
  function addArea(ds, ring, color, info, width = 2) {
    if (ring.length < 2) return;
    const flat = ring.flatMap(([lon, lat]) => [lon, lat]);
    if (ring.length >= 3) ds.entities.add({ polygon: { hierarchy: Cesium.Cartesian3.fromDegreesArray(flat),
      material: color.withAlpha(0.22), height: 0 }, wx: info });
    const closed = ring.length >= 3 ? flat.concat(flat.slice(0, 2)) : flat;
    ds.entities.add({ polyline: { positions: Cesium.Cartesian3.fromDegreesArrayHeights(
      closed.flatMap((v, i) => (i % 2 ? [v, 300] : [v]))), width, material: color, arcType: Cesium.ArcType.RHUMB }, wx: info });
  }
  function addCircle(ds, [lon, lat], radiusM, color, info) {
    ds.entities.add({ position: Cesium.Cartesian3.fromDegrees(lon, lat),
      ellipse: { semiMajorAxis: radiusM, semiMinorAxis: radiusM, material: color.withAlpha(0.22),
                 outline: true, outlineColor: color, height: 0 }, wx: info });
  }
  function addPoint(ds, [lon, lat], color, info, text) {
    ds.entities.add({ position: Cesium.Cartesian3.fromDegrees(lon, lat, 300),
      point: { pixelSize: 9, color, outlineColor: C.BLACK, outlineWidth: 1 },
      label: text ? { text, font: '13px sans-serif', fillColor: color, outlineColor: C.BLACK, outlineWidth: 3,
        style: Cesium.LabelStyle.FILL_AND_OUTLINE, pixelOffset: new Cesium.Cartesian2(10, -10),
        horizontalOrigin: Cesium.HorizontalOrigin.LEFT,
        distanceDisplayCondition: new Cesium.DistanceDisplayCondition(0, 1.2e7) } : undefined, wx: info });
  }

  // NWS warnings
  const NWS_COLORS = {
    'Tornado Warning': '#FF0000', 'Severe Thunderstorm Warning': '#FFA500', 'Flash Flood Warning': '#8B0000',
    'Flood Warning': '#00FF00', 'Special Marine Warning': '#FFA500', 'Tornado Watch': '#FFFF00',
    'Severe Thunderstorm Watch': '#DB7093', 'Winter Storm Warning': '#FF69B4', 'Blizzard Warning': '#FF4500',
    'Ice Storm Warning': '#8B008B', 'Winter Weather Advisory': '#7B68EE', 'High Wind Warning': '#DAA520',
    'Wind Advisory': '#D2B48C', 'Dense Fog Advisory': '#708090', 'Red Flag Warning': '#FF1493',
    'Hurricane Warning': '#DC143C', 'Tropical Storm Warning': '#B22222', 'Gale Warning': '#DDA0DD',
    'Storm Warning': '#9400D3', 'Small Craft Advisory': '#D8BFD8', 'Flood Watch': '#2E8B57',
    'Winter Storm Watch': '#4682B4', 'Heat Advisory': '#FF7F50', 'Excessive Heat Warning': '#C71585',
  };
  async function loadNws() {
    if (!WX.nws) { dropSource('nws'); status.nws = 'off'; return; }
    status.nws = 'loading…'; updatePanel();
    try {
      const { data, cachedAt } = await fetchFeed('https://api.weather.gov/alerts/active?status=actual');
      if (!WX.nws) return;
      const ds = source('nws'); ds.entities.removeAll();
      let n = 0;
      for (const f of data.features || []) {
        const g = f.geometry; if (!g) continue;
        const p = f.properties || {};
        const color = C.fromCssColorString(NWS_COLORS[p.event] || '#C0C0C0');
        const info = { title: p.headline || p.event, text: [p.event, p.areaDesc, p.description, p.instruction].filter(Boolean).join('\n\n') };
        const polys = g.type === 'Polygon' ? [g.coordinates] : g.type === 'MultiPolygon' ? g.coordinates : [];
        for (const poly of polys) { addArea(ds, poly[0].slice(0, -1), color, info); n++; }
      }
      status.nws = `${n} warning areas · ${when(cachedAt)}`;
    } catch (e) { status.nws = 'error: ' + e.message; }
    updatePanel(); viewer.scene.requestRender();
  }

  // NGA navigational warnings
  const NAV_AREAS = { A: 'HYDROLANT', P: 'HYDROPAC', C: 'HYDROARC', 4: 'NAVAREA IV', 12: 'NAVAREA XII' };
  const COORD = /(\d{1,2})-(\d{1,2}(?:\.\d+)?)(?:-(\d{1,2}(?:\.\d+)?))?\s*([NS])[\s,]*(\d{1,3})-(\d{1,2}(?:\.\d+)?)(?:-(\d{1,2}(?:\.\d+)?))?\s*([EW])/g;
  function coordsIn(text) {
    const out = [];
    for (const m of text.matchAll(COORD)) {
      const lat = (+m[1] + +m[2] / 60 + (m[3] ? +m[3] / 3600 : 0)) * (m[4] === 'S' ? -1 : 1);
      const lon = (+m[5] + +m[6] / 60 + (m[7] ? +m[7] / 3600 : 0)) * (m[8] === 'W' ? -1 : 1);
      if (Math.abs(lat) <= 90 && Math.abs(lon) <= 180) out.push([lon, lat]);
    }
    return out;
  }
  // Splits a warning into its lettered/numbered parts and turns each part's positions into a shape:
  // "WITHIN n MILES OF" + one position = circle; 3+ positions = area (or track line when the text
  // says TRACKLINE/BETWEEN/ALONG); 2 positions = line; 1 position = point.
  function parseNgaText(text) {
    const t = String(text || '').toUpperCase();
    const parts = t.split(/\n\s*(?=(?:[A-Z]|\d{1,2})\.\s)/);
    const shapes = [];
    for (const part of parts) {
      if (/^\s*\d{1,2}\.\s*CANCEL/.test(part)) continue;
      const pts = coordsIn(part);
      if (!pts.length) continue;
      const within = /WITHIN\s+(\d+(?:\.\d+)?)\s*(NM|NAUTICAL MILES?|MILES?|KM|KILOMETERS?|METERS?|YARDS?)/.exec(part);
      if (within && pts.length === 1) {
        const v = +within[1], u = within[2];
        const m = /^(NM|NAUTICAL|MILE)/.test(u) ? v * 1852 : /^K/.test(u) ? v * 1000 : /^Y/.test(u) ? v * 0.9144 : v;
        shapes.push({ type: 'circle', pts, radiusM: m });
      } else if (pts.length >= 3 && !/TRACK ?LINE|BETWEEN|ALONG/.test(part)) shapes.push({ type: 'polygon', pts });
      else if (pts.length >= 2) shapes.push({ type: 'line', pts });
      else shapes.push({ type: 'point', pts });
    }
    return shapes;
  }
  const isLaunch = (text) => /ROCKET|LAUNCH|SPACE DEBRIS|SPACECRAFT|MISSILE|REENTRY|RE-ENTRY/i.test(text || '');
  async function loadNaval() {
    if (!WX.naval) { dropSource('naval'); status.naval = 'off'; return; }
    status.naval = 'loading…'; updatePanel();
    const all = new Map(); let cachedAt = null, errors = [];
    await Promise.all(Object.keys(NAV_AREAS).map(async (a) => {
      try {
        const r = await fetchFeed(`https://msi.nga.mil/api/publications/broadcast-warn?navArea=${a}&status=active&output=json`);
        if (r.cachedAt) cachedAt = Math.min(cachedAt ?? Infinity, r.cachedAt);
        for (const w of r.data['broadcast-warn'] || []) all.set(`${w.navArea}:${w.msgYear}:${w.msgNumber}`, w);
      } catch (e) { errors.push(`${NAV_AREAS[a]}: ${e.message}`); }
    }));
    if (!WX.naval) return;
    const ds = source('naval'); ds.entities.removeAll();
    let n = 0, launch = 0;
    for (const w of all.values()) {
      const shapes = parseNgaText(w.text);
      if (!shapes.length) continue;
      const rocket = isLaunch(w.text);
      const color = rocket ? C.fromCssColorString('#FF6D00') : C.fromCssColorString('#40C4FF');
      const title = `${NAV_AREAS[w.navArea] || w.navArea} ${w.msgNumber}/${String(w.msgYear).slice(-2)}` +
        (w.subregion ? ` (${w.subregion})` : '') + (rocket ? ' · launch / debris hazard' : '');
      const info = { title, text: `${w.text}\n\nIssued ${w.issueDate || ''} by ${w.authority || 'NGA'}` };
      for (const s of shapes) {
        if (s.type === 'polygon') addArea(ds, s.pts, color, info, rocket ? 3 : 2);
        else if (s.type === 'line') addArea(ds, s.pts, color, info, rocket ? 3 : 2);
        else if (s.type === 'circle') addCircle(ds, s.pts[0], s.radiusM, color, info);
        else addPoint(ds, s.pts[0], color, info);
      }
      if (rocket) {
        const c = shapes[0].pts[0];
        addPoint(ds, c, color, info, '🚀 ' + title.split(' · ')[0]);
        launch++;
      }
      n++;
    }
    status.naval = `${n} warnings drawn (${launch} launch/debris) of ${all.size} active · ${when(cachedAt)}` +
      (errors.length ? ` · ${errors.join('; ')}` : '');
    updatePanel(); viewer.scene.requestRender();
  }

  // NHC hurricanes
  async function loadTropics() {
    if (!WX.tropics) { dropSource('tropics'); dropKml(); status.tropics = 'off'; return; }
    status.tropics = 'loading…'; updatePanel();
    try {
      const { data, cachedAt } = await fetchFeed('https://www.nhc.noaa.gov/CurrentStorms.json');
      if (!WX.tropics) return;
      const storms = data.activeStorms || [];
      const ds = source('tropics'); ds.entities.removeAll(); dropKml();
      for (const s of storms) {
        const lat = Number(s.latitudeNumeric), lon = Number(s.longitudeNumeric);
        const info = { title: `${s.classification || ''} ${s.name || s.id}`.trim(),
          text: `Intensity ${s.intensity ?? '?'} kt · pressure ${s.pressure ?? '?'} mb · moving ${s.movementDir ?? '?'}° at ${s.movementSpeed ?? '?'} mph\nLast update ${s.lastUpdate || ''}` };
        if (isFinite(lat) && isFinite(lon)) addPoint(ds, [lon, lat], C.fromCssColorString('#FF1744'), info, '🌀 ' + (s.name || s.id));
        for (const prod of [s.trackCone, s.forecastTrack]) if (prod && prod.kmzFile) addKml(prod.kmzFile);
      }
      status.tropics = storms.length ? `${storms.length} active storm${storms.length > 1 ? 's' : ''} · ${when(cachedAt)}`
        : `no active storms (Atlantic, E/C Pacific) · ${when(cachedAt)}`;
    } catch (e) { status.tropics = 'error: ' + e.message; }
    updatePanel(); viewer.scene.requestRender();
  }
  let kmlSources = [];
  function addKml(url) {
    Cesium.KmlDataSource.load(PX(url), { camera: viewer.scene.camera, canvas: viewer.scene.canvas, clampToGround: false })
      .then((ds) => { if (!WX.tropics) return; kmlSources.push(ds); viewer.dataSources.add(ds); viewer.scene.requestRender(); })
      .catch((e) => { status.tropics += ' · a storm graphic failed'; updatePanel(); });
  }
  function dropKml() { for (const ds of kmlSources) viewer.dataSources.remove(ds, true); kmlSources = []; }

  // ---------- Tap a warning for its text ----------
  const info = document.createElement('div');
  info.id = 'wxinfo'; info.className = 'panel';
  document.body.appendChild(info);
  const tapper = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);
  tapper.setInputAction((m) => {
    const hit = viewer.scene.drillPick(m.position, 6).map((p) => p.id).find((e) => e && (e.wx || (e.description && e.entityCollection && kmlSources.some((d) => d.entities === e.entityCollection))));
    if (!hit) { info.style.display = 'none'; return; }
    let title, text;
    if (hit.wx) ({ title, text } = hit.wx);
    else {
      title = hit.name || 'Storm graphic';
      const html = hit.description.getValue(Cesium.JulianDate.now()) || '';
      text = new DOMParser().parseFromString(html, 'text/html').body.textContent.replace(/\n\s*\n+/g, '\n').trim();
    }
    info.innerHTML = `<div class="hd"><b>${esc(title)}</b><button id="wxinfox">✕</button></div><div class="tx">${esc(text)}</div>`;
    info.style.display = 'block';
    document.getElementById('wxinfox').onclick = () => { info.style.display = 'none'; };
  }, Cesium.ScreenSpaceEventType.LEFT_CLICK);

  // ---------- Panel and time bar ----------
  const style = document.createElement('style');
  style.textContent = `
    #wxp { top: 62px; right: 10px; width: 320px; max-height: calc(100% - 290px); overflow-y: auto; display: none; font-family: sans-serif; }
    #wxp .row { display: flex; gap: 8px; align-items: flex-start; padding: 6px 0; border-bottom: 1px solid #223; }
    #wxp .row input { width: 20px; height: 20px; margin: 1px 0 0; flex: none; }
    #wxp .st { color: #9ab; font-size: 12px; margin-top: 2px; }
    #wxp .hd, #wxinfo .hd { display: flex; justify-content: space-between; align-items: center; }
    #wxp .note { color: #889; font-size: 11px; margin-top: 8px; }
    #wxt { bottom: 12px; left: 50%; transform: translateX(-50%); width: min(560px, calc(100% - 560px)); min-width: 280px;
           display: none; font-family: sans-serif; padding: 6px 10px; }
    #wxt .r { display: flex; align-items: center; gap: 8px; }
    #wxt input[type=range] { flex: 1; accent-color: #2a5bd7; height: 28px; }
    #wxt button { padding: 6px 10px; background: #1d2740; color: #fff; }
    #wxt .lab { font: 13px monospace; text-align: center; color: #cde; }
    #wxinfo { top: 62px; left: 50%; transform: translateX(-50%); width: min(520px, 80%); max-height: 55%; overflow-y: auto;
              display: none; font-family: sans-serif; z-index: 8; }
    #wxinfo .tx { white-space: pre-wrap; font: 12px/1.4 monospace; color: #dde; margin-top: 6px; }
    @media (max-width: 760px), (max-height: 520px) { #wxp { width: 260px; top: 96px; } #wxt { width: calc(100% - 210px); } }
  `;
  document.head.appendChild(style);

  const LAYERS = [
    ['clouds', 'Clouds (GOES / Himawari)', 'Type and opacity are in ⚙'],
    ['radar', 'Radar (U.S. NEXRAD)', ''],
    ['hrrr', 'Forecast radar (HRRR, U.S.)', ''],
    ['nws', 'NWS warnings (U.S.)', ''],
    ['naval', 'Naval warnings (NGA)', 'Launch / debris hazard areas in orange'],
    ['tropics', 'Hurricanes (NHC)', ''],
    ['daynight', 'Day / night shading', ''],
  ];
  const panel = document.createElement('div');
  panel.id = 'wxp'; panel.className = 'panel';
  document.body.appendChild(panel);
  const isOn = (k) => (k === 'clouds' ? cloudsOn() : !!WX[k]);
  function drawPanel() {
    panel.innerHTML = `<div class="hd"><b>Weather &amp; warnings</b><button id="wxpx">✕</button></div>` +
      LAYERS.map(([k, name, hint]) => `<label class="row"><input type="checkbox" data-k="${k}" ${isOn(k) ? 'checked' : ''}>
        <div><div>${name}</div><div class="st" id="wxs-${k}">${esc(hint)}</div></div></label>`).join('') +
      `<div class="note">For situational awareness only, not a flight or navigation briefing. Tap a warning on the globe for its text.</div>`;
    panel.querySelectorAll('input[data-k]').forEach((cb) => { cb.onchange = () => toggle(cb.dataset.k, cb.checked); });
    document.getElementById('wxpx').onclick = () => { panel.style.display = 'none'; };
    updatePanel();
  }
  function updatePanel() {
    for (const [k, , hint] of LAYERS) {
      const el = document.getElementById('wxs-' + k);
      if (el) el.textContent = isOn(k) ? (status[k] || hint) : hint;
    }
    const btn = document.getElementById('clouds');
    if (btn) btn.classList.toggle('on', LAYERS.some(([k]) => isOn(k)));
  }
  function toggle(k, on) {
    if (k === 'clouds') {
      settings.showClouds = on;
      if (on && settings.clouds === 'off') settings.clouds = 'ir';
      saveJSON('settings', settings);
    } else { WX[k] = on; save(); }
    if (k === 'hrrr' && on) refreshHrrrInit().then(applyTime);
    if (k === 'hrrr' && !on && offset > 0) offset = 0;
    if (k === 'nws') loadNws();
    if (k === 'naval') loadNaval();
    if (k === 'tropics') loadTropics();
    applyTime(); updateBarVisibility();
  }

  const bar = document.createElement('div');
  bar.id = 'wxt'; bar.className = 'panel';
  bar.innerHTML = `<div class="r"><button id="wxlayers" title="Weather layers">☰ Layers</button><button id="wxplay">▶</button>
    <input id="wxrange" type="range" step="1"><button id="wxlive">Live</button></div><div class="lab" id="wxlab"></div>`;
  document.body.appendChild(bar);
  const range = document.getElementById('wxrange');
  function updateBar() {
    range.min = -PAST_STEPS; range.max = WX.hrrr ? FUTURE_STEPS : 0; range.value = offset;
    const t = sliderTime();
    const rel = offset === 0 ? 'Live' : `${offset < 0 ? '−' : '+'}${Math.floor(Math.abs(offset) * 10 / 60)}:${pad(Math.abs(offset) * 10 % 60)}`;
    document.getElementById('wxlab').textContent = `${rel} · ${hhmm(t)}${offset > 0 ? ' · forecast' : ''}`;
    document.getElementById('wxlive').classList.toggle('on', offset === 0);
  }
  const timeAware = () => cloudsOn() || WX.radar || WX.hrrr || WX.daynight;
  function updateBarVisibility() {
    bar.style.display = tab === 'globe' && timeAware() ? 'block' : 'none';
    if (bar.style.display === 'none') stop();
  }
  let debounce = null;
  range.oninput = () => {
    offset = Number(range.value); updateBar();
    clearTimeout(debounce); debounce = setTimeout(applyTime, 250);
  };
  document.getElementById('wxlive').onclick = () => { stop(); offset = 0; applyTime(); };

  // Play: loops the past 2 h in 10 min steps, or the forecast in 30 min steps. Every frame of the
  // loop is preloaded first so the animation doesn't stall on tile downloads.
  let timer = null;
  function loopFrames() {
    if (offset > 0 && WX.hrrr) { const f = []; for (let k = 3; k <= FUTURE_STEPS; k += 3) f.push(k); return f; }
    const f = []; for (let k = -12; k <= 0; k++) f.push(k); return f;
  }
  function stop() { if (timer) { clearInterval(timer); timer = null; } document.getElementById('wxplay').textContent = '▶'; }
  document.getElementById('wxplay').onclick = () => {
    if (timer) { stop(); return; }
    const frames = loopFrames();
    const keep = offset;
    for (const k of frames) { offset = k; const t = sliderTime(); preload(t); }   // warm every frame
    offset = keep;
    let i = Math.max(0, frames.indexOf(offset));
    document.getElementById('wxplay').textContent = '❚❚';
    timer = setInterval(() => {
      i = (i + 1) % (frames.length + 2);                       // two extra ticks = pause on the last frame
      offset = frames[Math.min(i, frames.length - 1)];
      applyTime();
    }, 900);
  };
  function preload(t) {
    if (cloudsOn()) { const k = cloudKey(t); cloudFrames.ensure(k.key, makeClouds(k.iso, k.key)); }
    if (WX.radar && offset < 0) {
      const key = utcStamp(t);
      radarFrames.ensure(key, (set) => [viewer.imageryLayers.addImageryProvider(
        iemProvider(`ridge::USCOMP-N0Q-${key}`, 'c', set, 'NEXRAD via Iowa Environmental Mesonet'))]);
    }
    if (WX.hrrr && offset > 0 && hrrrInit) {
      const F = Math.round((t - hrrrInit) / (15 * MIN)) * 15;
      if (F >= 0 && F <= 1080) {
        const init = utcStamp(hrrrInit);
        hrrrFrames.ensure(`${init}F${F}`, (set) => [viewer.imageryLayers.addImageryProvider(
          iemProvider(`hrrr::REFD-F${pad(F, 4)}-${init}`, 'c', set, 'NOAA HRRR via Iowa Environmental Mesonet'))]);
      }
    }
  }

  // ---------- Wiring into the page ----------
  // The panel opens from the Weather button (top right) or from Layers on the time bar.
  function togglePanel() {
    const open = panel.style.display !== 'block';
    panel.style.display = open ? 'block' : 'none';
    if (open) drawPanel();
  }
  document.getElementById('clouds').textContent = 'Weather';
  document.getElementById('clouds').onclick = togglePanel;
  document.getElementById('wxlayers').onclick = togglePanel;
  window.wxOnTab = (name) => {
    if (name !== 'globe') { panel.style.display = 'none'; info.style.display = 'none'; }
    updateBarVisibility();
  };
  window.WX_API = {
    rebuildClouds() { cloudFrames.clear(); applyTime(); },
    setCloudAlpha(a) { cloudFrames.setAlpha(a); viewer.scene.requestRender(); },
    status: () => status, parseNgaText,
  };
  setInterval(() => { if (offset === 0) applyTime(); }, 5 * MIN);          // live frames roll forward
  setInterval(() => { if (WX.hrrr) refreshHrrrInit(); }, 20 * MIN);
  setInterval(() => { if (WX.nws) loadNws(); }, 5 * MIN);
  setInterval(() => { if (WX.naval) loadNaval(); }, 30 * MIN);
  setInterval(() => { if (WX.tropics) loadTropics(); }, 30 * MIN);
  window.addEventListener('online', () => { applyTime(); loadNws(); loadNaval(); loadTropics(); });

  if (WX.hrrr) refreshHrrrInit().then(applyTime);
  applyTime(); updateBarVisibility();
  loadNws(); loadNaval(); loadTropics();
})();
