// Satellite catalog. A built-in copy (compiled November 2026 from USCG NAVCEN and Wikipedia's
// GPS / Galileo / BeiDou satellite lists) ships with the app. When online, the app downloads
// satdb.json from the GitHub repo, keeps the newer of the two, and caches it for offline use.
// To update after a launch: edit satdb.json in the repo (same format) and bump "version".
// GPS rows: [PRN, SVN, name, block, plane/slot, launch]. Blocks starting with "III" (III, IIIF)
// are highlighted in gold.
(function (root) {
  // [PRN, SVN, name, block, plane/slot, launch]
  const BUILTIN = {
    version: '2026-11-15',
    gps: [
    [1, 80, 'GPS III SV07 "Sally Ride"', 'III', 'D2', '2024-12-17'],
    [2, 61, 'GPS IIR-13', 'IIR', 'D1', '2004-11-06'],
    [3, 69, 'GPS IIF-8', 'IIF', 'E1', '2014-10-29'],
    [4, 74, 'GPS III SV01 "Vespucci"', 'III', 'F4', '2018-12-23'],
    [5, 50, 'GPS IIR-M-8', 'IIR-M', 'E3', '2009-08-17'],
    [6, 67, 'GPS IIF-6', 'IIF', 'D4', '2014-05-17'],
    [7, 48, 'GPS IIR-M-6', 'IIR-M', 'A4', '2008-03-15'],
    [8, 72, 'GPS IIF-10', 'IIF', 'C3', '2015-07-15'],
    [9, 68, 'GPS IIF-7', 'IIF', 'F3', '2014-08-02'],
    [10, 73, 'GPS IIF-11', 'IIF', 'E2', '2015-10-31'],
    [11, 78, 'GPS III SV05 "Neil Armstrong"', 'III', 'D5', '2021-06-17'],
    [12, 58, 'GPS IIR-M-3', 'IIR-M', 'B4', '2006-11-17'],
    [13, 83, 'GPS III SV10 "Hedy Lamarr"', 'III', 'A5', '2026-04-21'],
    [14, 77, 'GPS III SV04 "Sacagawea"', 'III', 'B6', '2020-11-05'],
    [15, 55, 'GPS IIR-M-4', 'IIR-M', 'F2', '2007-10-17'],
    [16, 56, 'GPS IIR-8', 'IIR', 'B1', '2003-01-29'],
    [17, 53, 'GPS IIR-M-1', 'IIR-M', 'C4', '2005-09-26'],
    [18, 75, 'GPS III SV02 "Magellan"', 'III', 'D6', '2019-08-22'],
    [19, 59, 'GPS IIR-11', 'IIR', 'C5', '2004-03-20'],
    [20, 82, 'GPS III SV09 "Ellison Onizuka"', 'III', 'F5', '2026-01-28'],
    [21, 81, 'GPS III SV08 "Katherine Johnson"', 'III', 'E6', '2025-05-30'],
    [22, 44, 'GPS IIR-5', 'IIR', 'B3', '2000-07-16'],
    [23, 76, 'GPS III SV03 "Matthew Henson"', 'III', 'E5', '2020-06-30'],
    [24, 65, 'GPS IIF-3', 'IIF', 'A1', '2012-10-04'],
    [25, 62, 'GPS IIF-1', 'IIF', 'B2', '2010-05-28'],
    [26, 71, 'GPS IIF-9', 'IIF', 'B5', '2015-03-25'],
    [27, 66, 'GPS IIF-4', 'IIF', 'C2', '2013-05-15'],
    [28, 79, 'GPS III SV06 "Amelia Earhart"', 'III', 'A6', '2023-01-18'],
    [29, 57, 'GPS IIR-M-5', 'IIR-M', 'C1', '2007-12-20'],
    [30, 64, 'GPS IIF-5', 'IIF', 'A3', '2014-02-21'],
    [31, 52, 'GPS IIR-M-2', 'IIR-M', 'A2', '2006-09-25'],
    [32, 70, 'GPS IIF-12', 'IIF', 'F1', '2016-02-05'],
    ],
    // [PRN, GSAT, name, type, status, launch]
    galileo: [
    [1, 'GSAT0210', 'FOC FM10 "Danielė"', 'FOC', 'not usable', '2016-05-24'],
    [2, 'GSAT0211', 'FOC FM11 "Alizée"', 'FOC', '', '2016-05-24'],
    [3, 'GSAT0212', 'FOC FM12 "Lisa"', 'FOC', '', '2016-11-17'],
    [4, 'GSAT0213', 'FOC FM13 "Kimberley"', 'FOC', '', '2016-11-17'],
    [5, 'GSAT0214', 'FOC FM14 "Tijmen"', 'FOC', '', '2016-11-17'],
    [6, 'GSAT0227', 'FOC FM27', 'FOC', '', '2024-04-28'],
    [7, 'GSAT0207', 'FOC FM7 "Antonianna"', 'FOC', '', '2016-11-17'],
    [8, 'GSAT0208', 'FOC FM8 "Andriana"', 'FOC', '', '2015-12-17'],
    [9, 'GSAT0209', 'FOC FM9 "Liene"', 'FOC', '', '2015-12-17'],
    [10, 'GSAT0224', 'FOC FM24 "Shriya"', 'FOC', '', '2021-12-05'],
    [11, 'GSAT0101', 'IOV FM1 "Thijs"', 'IOV', '', '2011-10-21'],
    [12, 'GSAT0102', 'IOV FM2 "Natalia"', 'IOV', '', '2011-10-21'],
    [13, 'GSAT0220', 'FOC FM20 "Samuel"', 'FOC', '', '2018-07-25'],
    [14, 'GSAT0202', 'FOC FM2 "Milena"', 'FOC', 'not usable', '2014-08-22'],
    [15, 'GSAT0221', 'FOC FM21 "Anna"', 'FOC', '', '2018-07-25'],
    [16, 'GSAT0232', 'FOC FM32', 'FOC', '', '2024-09-17'],
    [18, 'GSAT0201', 'FOC FM1 "Doresa"', 'FOC', 'not usable', '2014-08-22'],
    [19, 'GSAT0103', 'IOV FM3 "David"', 'IOV', '', '2012-10-12'],
    [21, 'GSAT0215', 'FOC FM15 "Nicole"', 'FOC', '', '2017-12-12'],
    [22, 'GSAT0204', 'FOC FM4 "Anastasia"', 'FOC', 'not usable', '2015-03-27'],
    [23, 'GSAT0226', 'FOC FM26', 'FOC', '', '2024-09-17'],
    [25, 'GSAT0216', 'FOC FM16 "Zofia"', 'FOC', '', '2017-12-12'],
    [26, 'GSAT0203', 'FOC FM3 "Adam"', 'FOC', '', '2015-03-27'],
    [27, 'GSAT0217', 'FOC FM17 "Alexandre"', 'FOC', '', '2017-12-12'],
    [28, 'GSAT0233', 'FOC FM33', 'FOC', '', '2025-12-17'],
    [29, 'GSAT0225', 'FOC FM25', 'FOC', '', '2024-04-28'],
    [30, 'GSAT0206', 'FOC FM6 "Oriana"', 'FOC', '', '2015-09-11'],
    [31, 'GSAT0218', 'FOC FM18 "Irina"', 'FOC', '', '2017-12-12'],
    [32, 'GSAT0234', 'FOC FM34', 'FOC', '', '2025-12-17'],
    [33, 'GSAT0222', 'FOC FM22 "Ellen"', 'FOC', '', '2018-07-25'],
    [34, 'GSAT0223', 'FOC FM23 "Nikolina"', 'FOC', '', '2021-12-05'],
    [36, 'GSAT0219', 'FOC FM19 "Tara"', 'FOC', '', '2018-07-25'],
    ],
    // [PRN, name, orbit, generation, launch]
    beidou: [
    [1, 'Compass-G8', 'GEO', 'BDS-2', '2019-05-17'], [2, 'Compass-G6', 'GEO', 'BDS-2', '2012-10-25'],
    [3, 'Compass-G7', 'GEO', 'BDS-2', '2016-06-12'], [4, 'Compass-G4', 'GEO', 'BDS-2', '2010-10-31'],
    [5, 'Compass-G5', 'GEO', 'BDS-2', '2012-02-24'], [6, 'Compass-IGSO1', 'IGSO', 'BDS-2', '2010-07-31'],
    [7, 'Compass-IGSO2', 'IGSO', 'BDS-2', '2010-12-17'], [8, 'Compass-IGSO3', 'IGSO', 'BDS-2', '2011-04-09'],
    [9, 'Compass-IGSO4', 'IGSO', 'BDS-2', '2011-07-26'], [10, 'Compass-IGSO5', 'IGSO', 'BDS-2', '2011-12-01'],
    [11, 'Compass-M3', 'MEO', 'BDS-2', '2012-04-29'], [12, 'Compass-M4', 'MEO', 'BDS-2', '2012-04-29'],
    [13, 'Compass-IGSO6', 'IGSO', 'BDS-2', '2016-03-29'], [14, 'Compass-M6', 'MEO', 'BDS-2', '2012-09-18'],
    [16, 'Compass-IGSO7', 'IGSO', 'BDS-2', '2018-07-09'],
    [19, 'BeiDou-3 M1', 'MEO', 'BDS-3', '2017-11-05'], [20, 'BeiDou-3 M2', 'MEO', 'BDS-3', '2017-11-05'],
    [21, 'BeiDou-3 M3', 'MEO', 'BDS-3', '2018-02-12'], [22, 'BeiDou-3 M4', 'MEO', 'BDS-3', '2018-02-12'],
    [23, 'BeiDou-3 M5', 'MEO', 'BDS-3', '2018-07-29'], [24, 'BeiDou-3 M6', 'MEO', 'BDS-3', '2018-07-29'],
    [25, 'BeiDou-3 M11', 'MEO', 'BDS-3', '2018-08-24'], [26, 'BeiDou-3 M12', 'MEO', 'BDS-3', '2018-08-24'],
    [27, 'BeiDou-3 M7', 'MEO', 'BDS-3', '2018-01-11'], [28, 'BeiDou-3 M8', 'MEO', 'BDS-3', '2018-01-11'],
    [29, 'BeiDou-3 M9', 'MEO', 'BDS-3', '2018-03-29'], [30, 'BeiDou-3 M10', 'MEO', 'BDS-3', '2018-03-29'],
    [32, 'BeiDou-3 M13', 'MEO', 'BDS-3', '2018-09-19'], [33, 'BeiDou-3 M14', 'MEO', 'BDS-3', '2018-09-19'],
    [34, 'BeiDou-3 M15', 'MEO', 'BDS-3', '2018-10-15'], [35, 'BeiDou-3 M16', 'MEO', 'BDS-3', '2018-10-15'],
    [36, 'BeiDou-3 M17', 'MEO', 'BDS-3', '2018-11-18'], [37, 'BeiDou-3 M18', 'MEO', 'BDS-3', '2018-11-18'],
    [38, 'BeiDou-3 I1', 'IGSO', 'BDS-3', '2019-04-20'], [39, 'BeiDou-3 I2', 'IGSO', 'BDS-3', '2019-06-24'],
    [40, 'BeiDou-3 I3', 'IGSO', 'BDS-3', '2019-11-04'], [41, 'BeiDou-3 M19', 'MEO', 'BDS-3', '2019-12-16'],
    [42, 'BeiDou-3 M20', 'MEO', 'BDS-3', '2019-12-16'], [43, 'BeiDou-3 M21', 'MEO', 'BDS-3', '2019-11-23'],
    [44, 'BeiDou-3 M22', 'MEO', 'BDS-3', '2019-11-23'], [45, 'BeiDou-3 M23', 'MEO', 'BDS-3', '2019-09-22'],
    [46, 'BeiDou-3 M24', 'MEO', 'BDS-3', '2019-09-22'], [47, 'BeiDou-3 M25', 'MEO', 'BDS-3', '2024-09-19'],
    [48, 'BeiDou-3 M26', 'MEO', 'BDS-3', '2023-12-26'], [49, 'BeiDou-3 M27', 'MEO', 'BDS-3', '2024-09-19'],
    [50, 'BeiDou-3 M28', 'MEO', 'BDS-3', '2023-12-26'],
    [59, 'BeiDou-3 G1', 'GEO', 'BDS-3', '2018-11-01'], [60, 'BeiDou-3 G2', 'GEO', 'BDS-3', '2020-03-09'],
    [61, 'BeiDou-3 G3', 'GEO', 'BDS-3', '2020-06-23'], [62, 'BeiDou-3 G4', 'GEO', 'BDS-3', '2023-05-17'],
  ],
  };

  let db = {}, gps3 = new Set(), current = null;
  const key = (c, prn) => c + ':' + prn;

  function load(cat) {
    const next = {}, g3 = new Set();
    for (const [prn, svn, name, block, slot, launch] of cat.gps || []) {
      const hi = String(block).startsWith('III');
      next[key(1, prn)] = { c: 1, prn, svn: String(svn), name, block, orbit: 'MEO ' + (slot || ''), launch, gps3: hi };
      if (hi) g3.add(prn);
    }
    for (const [prn, gsat, name, type, status, launch] of cat.galileo || [])
      next[key(6, prn)] = { c: 6, prn, svn: gsat, name: 'Galileo ' + name, block: type, orbit: 'MEO', launch, note: status };
    for (const [prn, name, orbit, gen, launch] of cat.beidou || [])
      next[key(5, prn)] = { c: 5, prn, svn: '', name, block: gen, orbit, launch };
    if (!Object.keys(next).length) throw new Error('empty catalog');
    db = next; gps3 = g3; current = cat;
    api.all = Object.values(db); api.GPS3 = gps3; api.version = cat.version || '?';
  }

  function info(c, svid) {
    const hit = db[key(c, svid)];
    if (hit) return hit;
    switch (c) {
      case 3: return svid > 92
        ? { c, prn: svid, svn: '', name: `GLONASS FCN ${svid - 100}`, block: '', orbit: 'MEO', launch: '' }
        : { c, prn: svid, svn: '', name: `GLONASS slot ${svid}`, block: '', orbit: 'MEO', launch: '' };
      case 4: return { c, prn: svid, svn: '', name: `QZSS PRN ${svid}`, block: '', orbit: 'IGSO/GEO', launch: '' };
      case 2: return { c, prn: svid, svn: '', name: `SBAS PRN ${svid}`, block: '', orbit: 'GEO', launch: '' };
      case 7: return { c, prn: svid, svn: '', name: `NavIC ${svid}`, block: '', orbit: 'GEO/IGSO', launch: '' };
      default: return { c, prn: svid, svn: '', name: 'Unknown', block: '', orbit: '', launch: '' };
    }
  }

  // Use whichever catalog is newest: built-in, cached from an earlier download, or freshly downloaded.
  const newer = (a, b) => String(a.version || '') > String(b.version || '');
  function tryCached() {
    try {
      const c = JSON.parse(localStorage.getItem('satdb') || 'null');
      if (c && newer(c, BUILTIN)) { load(c); api.source = 'downloaded ' + c.version + ' (cached)'; }
    } catch (e) { /* keep built-in */ }
  }
  async function refresh(url) {
    if (!url || !navigator.onLine) return false;
    try {
      const r = await fetch(url + '?t=' + Date.now(), { cache: 'no-store' });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const cat = await r.json();
      if (!newer(cat, current) && current) return false;
      load(cat);
      try { localStorage.setItem('satdb', JSON.stringify(cat)); } catch (e) {}
      api.source = 'downloaded ' + cat.version;
      return true;
    } catch (e) {
      api.lastError = String(e.message || e);
      return false;
    }
  }

  const api = { info, load, refresh, builtin: BUILTIN, source: 'built-in ' + BUILTIN.version };
  load(BUILTIN);
  if (typeof localStorage !== 'undefined') tryCached();
  if (typeof module !== 'undefined') module.exports = api; else root.SATDB = api;
})(this);
