# GNSS Globe

Android app for a Samsung tablet. Reads live data from the tablet's own GNSS chip and
shows it fully offline:

- **Globe** (Cesium): your position, straight lines to every satellite in view, colour-coded
  by constellation. Bold = used in fix. Solid line = true position from GPS broadcast
  ephemeris decoded on the tablet; dashed = nominal orbit height along the measured direction.
  Faint loops = 12 h GPS orbit tracks.
- **Sky plot**: azimuth/elevation polar plot, ◎ ring = dual-frequency.
- **Signals**: C/N0 bars per satellite and band (L1/E1/B1, L5/E5a/B2a, ...).
- **Satellites**: PRN, SVN, long name (e.g. GPS III SV01 "Vespucci"), block, orbit, launch date,
  live status. Catalog in `app/src/main/assets/web/satdb.js` (compiled Nov 2026).
- GPS III satellites are drawn in gold. Tap a constellation in the legend to hide/show it.
- **⚙ Settings**: paste a Cesium ion token (stored only on the tablet) for high-resolution
  imagery and optional 3D terrain when online. The offline globe stays underneath.
- Works in Samsung pop-up view (floating, resizable window).

GPS ephemeris comes from raw navigation messages (GnssNavigationMessage, LNAV subframes 2-3,
IS-GPS-200) and is cached for 4 h so it survives offline restarts. Some chips don't share
navigation messages; the app then falls back to nominal heights and says so on screen.

GitHub Actions builds the APK on every push (Actions tab → latest run → Artifacts).
