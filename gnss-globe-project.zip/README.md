# GNSS Globe

Android app for a Samsung tablet. Reads live data from the tablet's own GNSS chip and
shows it fully offline:

- **Globe** (Cesium): your position, straight lines to every satellite in view, colour-coded
  by constellation. Bold = used in fix. Solid line = true position from GPS broadcast
  ephemeris decoded on the tablet; dashed = nominal orbit height along the measured direction.
  Faint loops = 12 h GPS orbit tracks.
- **Sky plot**: azimuth/elevation polar plot, ◎ ring = more than one signal tracked (e.g. L1 C/A + L1C).
- **Signals**: C/N0 bars per satellite and band (L1/E1/B1, L5/E5a/B2a, ...).
- **Satellites**: PRN, SVN, long name (e.g. GPS III SV01 "Vespucci"), block, orbit, launch date,
  live status. Catalog in `app/src/main/assets/web/satdb.js` (compiled Nov 2026).
- GPS III satellites are drawn in gold. Tap a constellation in the legend to hide/show it.
- **⚙ Settings**: paste a Cesium ion token (stored only on the tablet) for high-resolution
  imagery and optional 3D terrain when online. The offline globe stays underneath.
- **Local map**: a second Cesium view in 2D (bottom right of the Globe tab) with position,
  heading arrow, breadcrumb trail and ground speed in mph. Bing road map with an ion token,
  OpenStreetMap otherwise; street detail needs internet.
- **Live clouds**: NOAA GOES-East infrared or GeoColor straight from NOAA NESDIS, plus optional
  GOES-West/Himawari infrared via NASA GIBS. Refreshes every 10 min while online (Clouds button / ⚙).
- **Catalog auto-update**: the app downloads `satdb.json` from this repo/branch when online and
  keeps the newest version (compared by its "version" field). Edit that file after a launch;
  no rebuild needed. Blocks starting with "III" (III, IIIF) show in gold.
- **Branches**: builds from `main` install as "GNSS Globe"; builds from any other branch
  (e.g. `dev`) install as a separate "GNSS Globe Dev" app with a purple icon.
- Works in Samsung pop-up view (floating, resizable window).

GPS ephemeris comes from raw navigation messages (GnssNavigationMessage, LNAV subframes 2-3,
IS-GPS-200) and is cached for 4 h so it survives offline restarts. Some chips don't share
navigation messages; the app then falls back to nominal heights and says so on screen.

GitHub Actions builds the APK on every push (Actions tab → latest run → Artifacts).
