# GNSS Globe

Android app for a Samsung tablet. Reads live satellite data from the tablet's own
GNSS chip and shows it on an offline Cesium 3D globe: your position, a line to every
satellite in view, colour-coded by constellation, with satellites used in the fix in bold.

GitHub Actions builds the APK on every push (Actions tab → latest run → gnss-globe-apk).
The build downloads Cesium and bundles it into the app, so the app needs no internet.

Satellite directions come straight from the receiver (azimuth/elevation). Distances are
nominal orbit radii per constellation, since the receiver does not report range.
